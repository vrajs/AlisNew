import { Component, OnInit } from '@angular/core';
import { CoreComponentModel } from '@app/core/models';
import { AuthService, LocalStoreManagerService } from '@app/core/services';
import { AppConstant } from './common/app-constants';
import { Utils } from './common/app-functions';
import { ThemeLayoutsComponent } from './modules/admin/docs/guides/customization/theme-layouts/theme-layouts';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent extends CoreComponentModel implements OnInit {
    /**
     * Constructor
     */
    constructor(
        private localStorage: LocalStoreManagerService,
        private authService: AuthService
    ) {
        super();
    }

    ngOnInit(): void {
        this.currentGetUserInfo();
        this.currentUserSettings();
    }

    currentGetUserInfo() {
        let userData = this.localStorage.getData(AppConstant.CURRENT_USER);
        if (!Utils.isBlank(userData)) {
            this.authService._currentUserInfo.next(userData);
        }
    }
    currentUserSettings() {
        var themeSchemeAndLayout = this.localStorage.localStorageGetItem(
            'themeSchemeAndLayout'
        );
        if (
            !Utils.isBlank(themeSchemeAndLayout) &&
            !Utils.isBlank(themeSchemeAndLayout.density == 'cosy')
        ) {
            document.body.classList.remove('density-compact');
            document.body.classList.remove('density-comfortable');
            document.body.classList.remove('density-cosy');
            document.body.classList.add('density-cosy');
        } else if (
            !Utils.isBlank(themeSchemeAndLayout) &&
            !Utils.isBlank(themeSchemeAndLayout.density == 'compact')
        ) {
            document.body.classList.remove('density-cosy');
            document.body.classList.remove('density-compact');
            document.body.classList.remove('density-comfortable');
            document.body.classList.add('density-compact');
        } else if (
            !Utils.isBlank(themeSchemeAndLayout) &&
            !Utils.isBlank(themeSchemeAndLayout.density == 'comfortable')
        ) {
            document.body.classList.remove('density-comfortable');
            document.body.classList.remove('density-compact');
            document.body.classList.remove('density-cosy');
            document.body.classList.add('density-comfortable');
        } else {
            document.body.classList.remove('density-compact');
            document.body.classList.remove('density-comfortable');
            document.body.classList.remove('density-cosy');
        }
    }
}
