import * as CryptoJS from 'crypto-js';
// import { KeyVal } from "../view-models/keyval";
import * as moment from 'moment';
// import { conformToMask } from 'angular2-text-mask';
// import { SystemSettingModel } from "../modules/master/models/systemSetting.model";
import { DateFilterType, Gender, GenderById, HpsGridFieldType, NumericFilterType, RecordStatus, StringFilterType } from '@app/common/app-global';
// import { T } from "@angular/core/src/render3";
// import { DATE } from 'ngx-bootstrap/chronos/units/constants';
import { HttpResponse } from '@angular/common/http';
import { HpsGridColumn, KeyValModel } from '@app/core/models';
import { camelCase } from 'lodash';
//const appSettings = require('../../../appsettings.json');


export class Utils {


    public static readonly captionAndMessageSeparator = ":";
    public static readonly noNetworkMessageCaption = "No Network";
    public static readonly noNetworkMessageDetail = "The server cannot be reached";
    public static readonly accessDeniedMessageCaption = "Access Denied!";
    public static readonly accessDeniedMessageDetail = "";

    static getFormatedValue(value: any, col: HpsGridColumn, defaultText?: string, functionName?: string): string {

        if (!Utils.isBlank(col.customeFunction)) {
            return Utils.dynamicFormatedValue(value, functionName);
        }

        if (col.fieldType === HpsGridFieldType.Boolean) {
            return (value === true || value === 'true' || value === 1) ? 'Yes' : 'No';
        } else if (col.fieldType === HpsGridFieldType.Date) {
            if (!Utils.isBlank(value)) {
                return Utils.dateFormatter(value)
            }
            else {
                if (!Utils.isBlank(defaultText))
                    return defaultText
            }
        } else if (col.fieldType === HpsGridFieldType.Phone) {
            if (!Utils.isBlank(value)) {
                //return this.phone.transform(value);
            }
        } else if (col.fieldType === HpsGridFieldType.Number) {
            if ((Utils.isBlank(value) && !Utils.isBlank(defaultText))) {
                if (value === 0) {
                    return value;
                } else {
                    return defaultText;
                }
            }
            else {
                return value;
            }
        } else if (col.fieldType === HpsGridFieldType.DateTime) {
            if (!Utils.isBlank(value)) {
                return Utils.dateFormatter(value) + " at " + this.printTimeOnly(value);
            }
            else {
                if (!Utils.isBlank(defaultText))
                    return defaultText
            }
        }
        else {
            if (Utils.isBlank(value) && !Utils.isBlank(defaultText))
                return defaultText;
            else
                return value;
        }
    }

    static dynamicFormatedValue(value: any, functionName: string) {
        if (!Utils.isBlank(functionName)) {
            switch (functionName) {
                case "setActiveInactive":
                    return this.setActiveInactive(value);
                case "formatFacilityNonFacility":
                    return this.formatFacilityNonFacility(value);
                case "genderFormatter":
                    return this.genderFormatter(value);
            }
        }
    }

    static formatFacilityNonFacility(val: string): string {
        if (val == 'F') {
            return "Facility";
        }
        else if (val == 'NF') {
            return "Non-Facility";
        } else {
            return "N/A"
        }
    }

    static setActiveInactive(val: number) {
        return val === 0 ? 'Active' : 'Inactive';
    }


    static camelizeKeys = (obj) => {

        if (Array.isArray(obj)) {
            return obj.map(v => Utils.camelizeKeys(v));
        } else if (!Utils.isBlank(obj) && obj.constructor === Object) {
            return Object.keys(obj).reduce(
                (result, key) => ({
                    ...result,
                    [camelCase(key)]: Utils.camelizeKeys(obj[key]),
                }),
                {},
            );
        }
        return obj;
    }

    public static getHttpResponseMessage(data: HttpResponse<any> | any): string[] {

        let responses: string[] = [];

        if (data instanceof HttpResponse) {

            if (this.checkNoNetwork(data)) {
                responses.push(`${this.noNetworkMessageCaption}${this.captionAndMessageSeparator} ${this.noNetworkMessageDetail}`);
            }
            else {
                try {
                    let responseObject = data.body.json();

                    for (let key in responseObject) {
                        if (key)
                            responses.push(`${key}${this.captionAndMessageSeparator} ${responseObject[key]}`);
                        else if (responseObject[key])
                            responses.push(responseObject[key].toString());
                    }
                }
                catch (error) {
                }
            }

            if (!responses.length && data.body.text())
                responses.push(data.body.text());
        }

        if (!responses.length)
            responses.push(data.toString());

        if (this.checkAccessDenied(data))
            responses.splice(0, 0, `${this.accessDeniedMessageCaption}${this.captionAndMessageSeparator} ${this.accessDeniedMessageDetail}`);


        return responses;
    }

    public static findHttpResponseMessage(messageToFind: string, data: Response | any, seachInCaptionOnly = true, includeCaptionInResult = false): string {

        let searchString = messageToFind.toLowerCase();
        let httpMessages = this.getHttpResponseMessage(data);

        for (let message of httpMessages) {
            let fullMessage = this.splitInTwo(message, this.captionAndMessageSeparator);

            if (fullMessage.firstPart && fullMessage.firstPart.toLowerCase().indexOf(searchString) != -1) {
                return includeCaptionInResult ? message : fullMessage.secondPart || fullMessage.firstPart;
            }
        }

        if (!seachInCaptionOnly) {
            for (let message of httpMessages) {

                if (message.toLowerCase().indexOf(searchString) != -1) {
                    if (includeCaptionInResult) {
                        return message;
                    }
                    else {
                        let fullMessage = this.splitInTwo(message, this.captionAndMessageSeparator);
                        return fullMessage.secondPart || fullMessage.firstPart;
                    }
                }
            }
        }

        return null;
    }

    public static checkNoNetwork(response: HttpResponse<any>) {
        if (response instanceof HttpResponse) {
            return response.status == 0;
        }

        return false;
    }

    public static checkAccessDenied(response: HttpResponse<any>) {
        if (response instanceof HttpResponse) {
            return response.status == 403;
        }

        return false;
    }

    public static checkNotFound(response: HttpResponse<any>) {
        if (response instanceof HttpResponse) {
            return response.status == 404;
        }

        return false;
    }

    public static checkIsLocalHost(url: string, base?: string) {
        if (url) {
            let location = new URL(url, base);
            return location.hostname === "localhost" || location.hostname === "127.0.0.1";
        }

        return false;
    }

    public static splitInTwo(text: string, separator: string): { firstPart: string, secondPart: string } {
        let separatorIndex = text.indexOf(separator);

        if (separatorIndex == -1)
            return { firstPart: text, secondPart: null };

        let part1 = text.substr(0, separatorIndex).trim();
        let part2 = text.substr(separatorIndex + 1).trim();

        return { firstPart: part1, secondPart: part2 };
    }

    public static safeStringify(object) {

        let result: string;

        try {
            result = JSON.stringify(object);
            return result;
        }
        catch (error) {

        }

        let simpleObject = {};

        for (let prop in object) {
            if (!object.hasOwnProperty(prop)) {
                continue;
            }
            if (typeof (object[prop]) == 'object') {
                continue;
            }
            if (typeof (object[prop]) == 'function') {
                continue;
            }
            simpleObject[prop] = object[prop];
        }

        result = "[***Sanitized Object***]: " + JSON.stringify(simpleObject);

        return result;
    }

    public static JSonTryParse(value: string) {
        try {
            return JSON.parse(value);
        }
        catch (e) {
            if (value === "undefined")
                return void 0;

            return value;
        }
    }

    public static TestIsUndefined(value: any) {
        return typeof value === 'undefined';
        //return value === undefined;
    }

    public static TestIsString(value: any) {
        return typeof value === 'string' || value instanceof String;
    }

    public static capitalizeFirstLetter(text: string) {
        if (text)
            return text.charAt(0).toUpperCase() + text.slice(1);
        else
            return text;
    }

    public static toTitleCase(text: string) {
        return text.replace(/\w\S*/g, (subString) => {
            return subString.charAt(0).toUpperCase() + subString.substr(1).toLowerCase();
        });
    }

    public static toLowerCase(items: string)
    public static toLowerCase(items: string[])
    public static toLowerCase(items: any): string | string[] {

        if (items instanceof Array) {
            let loweredRoles: string[] = [];

            for (let i = 0; i < items.length; i++) {
                loweredRoles[i] = items[i].toLowerCase();
            }

            return loweredRoles;
        }
        else if (typeof items === 'string' || items instanceof String) {
            return items.toLowerCase();
        }
    }

    public static uniqueId() {
        return this.randomNumber(1000000, 9000000).toString();
    }

    public static randomNumber(min: number, max: number) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    public static baseUrl() {
        if (window.location.origin)
            return window.location.origin

        return window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
    }

    public static printDateOnly(date: Date) {

        date = new Date(date);

        let dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
        let monthNames = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

        let dayOfWeek = date.getDay();
        let dayOfMonth = date.getDate();
        let sup = "";
        let month = date.getMonth();
        let year = date.getFullYear();

        if (dayOfMonth == 1 || dayOfMonth == 21 || dayOfMonth == 31) {
            sup = "st";
        }
        else if (dayOfMonth == 2 || dayOfMonth == 22) {
            sup = "nd";
        }
        else if (dayOfMonth == 3 || dayOfMonth == 23) {
            sup = "rd";
        }
        else {
            sup = "th";
        }

        let dateString = dayNames[dayOfWeek] + ", " + dayOfMonth + sup + " " + monthNames[month] + " " + year;

        return dateString;
    }

    public static printTimeOnly(date: Date) {

        date = new Date(date);

        let period = "";
        let minute = date.getMinutes().toString();
        let hour = date.getHours();

        period = hour < 12 ? "AM" : "PM";

        if (hour == 0) {
            hour = 12;
        }
        if (hour > 12) {
            hour = hour - 12;
        }

        if (minute.length == 1) {
            minute = "0" + minute;
        }

        let timeString = hour + ":" + minute + " " + period;


        return timeString;
    }

    public static printDate(date: Date) {
        return this.printDateOnly(date) + " at " + this.printTimeOnly(date);
    }

    public static parseDate(date) {

        if (date) {

            if (date instanceof Date) {
                return date;
            }

            if (typeof date === 'string' || date instanceof String) {
                if (date.search(/[a-su-z+]/i) == -1)
                    date = date + "Z";

                return new Date(date);
            }

            if (typeof date === 'number' || date instanceof Number) {
                return new Date(<any>date);
            }
        }
    }

    public static printDuration(start: Date, end: Date) {

        start = new Date(start);
        end = new Date(end);

        // get total seconds between the times
        let delta = Math.abs(start.valueOf() - end.valueOf()) / 1000;

        // calculate (and subtract) whole days
        let days = Math.floor(delta / 86400);
        delta -= days * 86400;

        // calculate (and subtract) whole hours
        let hours = Math.floor(delta / 3600) % 24;
        delta -= hours * 3600;

        // calculate (and subtract) whole minutes
        let minutes = Math.floor(delta / 60) % 60;
        delta -= minutes * 60;

        // what's left is seconds
        let seconds = delta % 60;  // in theory the modulus is not required


        let printedDays = "";

        if (days)
            printedDays = `${days} days`;

        if (hours)
            printedDays += printedDays ? `, ${hours} hours` : `${hours} hours`;

        if (minutes)
            printedDays += printedDays ? `, ${minutes} minutes` : `${minutes} minutes`;

        if (seconds)
            printedDays += printedDays ? ` and ${seconds} seconds` : `${seconds} seconds`;


        if (!printedDays)
            printedDays = "0";

        return printedDays;
    }

    public static getAge(birthDate, otherDate) {
        birthDate = new Date(birthDate);
        otherDate = new Date(otherDate);

        let years = (otherDate.getFullYear() - birthDate.getFullYear());

        if (otherDate.getMonth() < birthDate.getMonth() ||
            otherDate.getMonth() == birthDate.getMonth() && otherDate.getDate() < birthDate.getDate()) {
            years--;
        }

        return years;
    }

    public static removeNulls(obj) {
        let isArray = obj instanceof Array;

        for (let k in obj) {
            if (obj[k] === null) {
                isArray ? obj.splice(k, 1) : delete obj[k];
            }
            else if (typeof obj[k] == "object") {
                this.removeNulls(obj[k]);
            }

            if (isArray && obj.length == k) {
                this.removeNulls(obj);
            }
        }

        return obj;
    }

    public static debounce(func: (...args) => any, wait: number, immediate?: boolean) {
        var timeout;

        return function () {
            var context = this;
            var args_ = arguments;

            var later = function () {
                timeout = null;
                if (!immediate)
                    func.apply(context, args_);
            };

            var callNow = immediate && !timeout;

            clearTimeout(timeout);
            timeout = setTimeout(later, wait);

            if (callNow)
                func.apply(context, args_);
        };
    };

    //JWT Helpers method

    public static urlBase64Decode(str: string): string {
        let output = str.replace(/-/g, '+').replace(/_/g, '/');
        switch (output.length % 4) {
            case 0: { break; }
            case 2: { output += '=='; break; }
            case 3: { output += '='; break; }
            default: {
                throw 'Illegal base64url string!';
            }
        }
        return this.b64DecodeUnicode(output);
    }

    private static b64DecodeUnicode(str: any) {
        return decodeURIComponent(Array.prototype.map.call(atob(str), (c: any) => {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
    }

    public static decodeToken(token: string): any {
        let parts = token.split('.');

        if (parts.length !== 3) {
            throw new Error('JWT must have 3 parts');
        }

        let decoded = this.urlBase64Decode(parts[1]);
        if (!decoded) {
            throw new Error('Cannot decode the token');
        }

        return JSON.parse(decoded);
    }

    public static getTokenExpirationDate(token: string): Date {
        let decoded: any;
        decoded = this.decodeToken(token);

        if (!decoded.hasOwnProperty('exp')) {
            return null;
        }

        let date = new Date(0);
        date.setUTCSeconds(decoded.exp);

        return date;
    }

    public static isTokenExpired(token: string, offsetSeconds?: number): boolean {
        let date = this.getTokenExpirationDate(token);
        offsetSeconds = offsetSeconds || 0;

        if (date == null) {
            return false;
        }

        // Token expired?
        return !(date.valueOf() > (new Date().valueOf() + (offsetSeconds * 1000)));
    }


    static isBlank(val: any): boolean {
        return val == undefined || val == null || val == '' || val == "" || val == " ";
    }

    static isBlankWithNull(val: any): boolean {
        return val == undefined || val == null;
    }

    static isBlankZero(val: any): any {
        return val == undefined || val == null || val == '' || val == "" || val == " " ? 0 : val;
    }
    //use for display 'Yes' or 'No' if column has boolean value in grid 
    static flagFormatter(val) {
        return val === true ? "Yes" : "No";
    }
    //use for display '' or 'Specific Date' if column has 9999-12-31 value in grid 
    static dateFormatter(val: Date) {
        if (!Utils.isBlank(val)) {
            val = typeof val == "string" ? new Date(val) : val;
            if (val.getFullYear() == 9999 && val.getMonth() + 1 == 12 && val.getDate() == 31) {
                return val.getMonth() + 1 + "/" + val.getDate() + "/" + val.getFullYear();
            }
            else { return val.getMonth() + 1 + "/" + val.getDate() + "/" + val.getFullYear(); }
        }
        else {
            return '';
        }
    }
    static genderFormatter(val: string) {
        switch (val) {
            case "B":
                return "Both";
            case "M":
                return "Male";
            case "F":
                return "Female";
            default:
                return "N/A";
        }
    }

    static genderFormatterById(val: number) {
        switch (val) {
            case Gender.Both:
                return "Both";
            case Gender.Male:
                return "Male";
            case Gender.Female:
                return "Female";
            case Gender.Unknown:
                return "Unknown";
            default:
                return "N/A";
        }
    }

    static genderFormatterByGenderId(val: number) {
        switch (Number(val)) {
            case GenderById.Male:
                return "Male";
            case GenderById.Female:
                return "Female";
            case GenderById.Unknown:
                return "Unknown";
        }
    }
    //use for getting date as null when date is max 
    static getDate(val: Date): Date {
        return (val.toString().split('T')[0]) == '9999-12-31' ? null : new Date(val);
    }
    //use for setting date as max when date is null
    static setDate(val: any): Date {
        return this.isBlank(val) ? new Date('9999-12-31') : new Date(val);
    }


    // Start Akash

    static findInvalidControlsFromForm(ngForm): any[] {
        let invalid = [];
        let controls = ngForm.controls;
        for (let name in controls) {
            if (controls[name].invalid) {
                invalid.push(name);
                let error = controls[name].errors;
            }
        }
        return invalid;
    }

    static formatDate(data): string {
        var date = null;
        if (this.isBlank(data)) {
            date = new Date();
        }
        else {
            date = new Date(data);
        }
        var day = date.getDate();           // yields 
        var month = date.getMonth() + 1;    // yields month
        var year = date.getFullYear();      // yields year
        // After this construct a string with the above results as below
        month = month.toString().length == 1 ? "0" + month : month;
        day = day.toString().length == 1 ? "0" + day : day;
        var formattedDate = month + "/" + day + "/" + year;
        return formattedDate;
    };

    static formateTime(data): string {
        var date = null;
        if (this.isBlank(data)) {
            date = new Date();
        }
        else {
            date = new Date(data);
        }
        var hour = date.getHours();         // yields hours 
        var minute = date.getMinutes();     // yields minutes
        var second = date.getSeconds();     // yields seconds

        // After this construct a string with the above results as below
        var time = hour + ':' + minute + ':' + second;
        return time;
    };

    static convert12hourTo24hourFormat(time): string {
        if (!this.isBlank(time))
            return moment(time, ["h:mm A"]).format("HH:mm");
    };

    static Convert24hourTo12hourFormat(time): string {
        if (!this.isBlank(time))
            return moment(time, 'HH:mm').format('hh:mm A');
    };
    // End Akash

    // This method return text mask of Home Phone number field
    static getTextMaskForHomePhone(isInfragistics?: boolean): any {
        if (isInfragistics) {
            return "(###) ###-####";
        }
        else {
            return {
                mask: ['(', /[1-9]/, /\d/, /\d/, ')',
                    ' ', /\d/, /\d/, /\d/,
                    '-', /\d/, /\d/, /\d/, /\d/]
            };
        }
    }

    // This method return text mask of Work Phone number field
    static getTextMaskForWorkPhone(isInfragistics?: boolean): any {
        if (isInfragistics) {
            return "(###) ###-####";
        }
        else {
            return {
                mask: ['(', /[1-9]/, /\d/, /\d/, ')',
                    ' ', /\d/, /\d/, /\d/,
                    '-', /\d/, /\d/, /\d/, /\d/]
            };
        }
    }

    // This method return text mask of Mobile Phone number field
    static getTextMaskForMobilePhone(isInfragistics?: boolean): any {
        if (isInfragistics) {
            return "(###) ###-####";
        }
        else {
            return {
                mask: ['(', /[1-9]/, /\d/, /\d/, ')',
                    ' ', /\d/, /\d/, /\d/,
                    '-', /\d/, /\d/, /\d/, /\d/]
            };
        }
    }

    static getEmailPattern(): string {
        return "/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/";
    }

    // This method return text mask of Mobile Phone number field
    static getTextMaskForSSN(): any {
        return {
            mask: [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/]
        };
    }

    // static convertSSNToTextMask(ssn: string): string {
    //     let objSSNMask = conformToMask(ssn, Utils.getTextMaskForSSN().mask, { guide: false });
    //     return objSSNMask.conformedValue;
    // }

    // static convertPhoneNumberToTextMask(phoneNumber: string): string {
    //     let objPhoneNumberMask = conformToMask(phoneNumber, Utils.getTextMaskForHomePhone().mask, { guide: false });
    //     return objPhoneNumberMask.conformedValue;
    // }

    static convertAcccountNoToMask(accountNo: string): string {
        accountNo = accountNo.replace(/\d(?=\d{4})/g, "*");
        return accountNo;
    }

    static convertCVSToMask(CVS: any): string {
        if (typeof CVS === "number") {
            CVS = CVS.toString();
        }
        CVS = CVS.replace(/\d(?=\d{0})/g, "*");
        return CVS;
    }

    static convertStringToMask(accountNo: string, displayChar: string): string {
        accountNo = accountNo.replace("/\d(?=\d{" + displayChar + "})/g", "*");
        return accountNo;
    }

    // static createIgDatePickerRequire(errorMessage: string, selectorId?: string): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             selector: "#" + selectorId,
    //             errorMessage: errorMessage,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-date-picker").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-date-picker").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-date-picker").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-date-picker").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    // }

    // static createIgComboRequire(errorMessage: string, selectorId?: string): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             onchange: true,
    //             selector: "#" + selectorId,
    //             errorMessage: errorMessage,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             onchange: true,
    //             errorMessage: errorMessage,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    // }

    // static createIgComboCustom(errorMessage: string, selectorId?: string, flag?: boolean): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             onsubmit: true,
    //             onchange: true,
    //             selector: "#" + selectorId,
    //             custom: {
    //                 method: (value, fieldOptions): boolean => {
    //                     return flag;
    //                 },
    //                 errorMessage: errorMessage
    //             },
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             onsubmit: true,
    //             onchange: true,
    //             custom: {
    //                 method: (value, fieldOptions): boolean => {
    //                     return flag;
    //                 },
    //                 errorMessage: errorMessage
    //             },
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-combo").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    // }

    // static createIgNumericRequire(errorMessage: string, selectorId?: string): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: true,
    //             selector: "#" + selectorId,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-numeric-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-numeric-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: true,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-numeric-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-numeric-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    // }

    // static createIgCurrencyRequire(errorMessage: string, selectorId?: string): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: true,
    //             selector: "#" + selectorId,
    //             custom: {
    //                 method: (value, fieldOptions): boolean => {
    //                     if (value == "0.00") {
    //                         return false;
    //                     }
    //                     else {
    //                         return true;
    //                     }
    //                 },
    //                 errorMessage: errorMessage
    //             },
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: false,
    //             onblur: true,
    //             custom: {
    //                 method: (value, fieldOptions): boolean => {
    //                     if (value == "0.00") {
    //                         return false;
    //                     }
    //                     else {
    //                         return true;
    //                     }
    //                 },
    //                 errorMessage: errorMessage
    //             },
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }

    // }

    // static createIgCurrencyRequireWithoutZero(errorMessage: string, selectorId?: string): object {
    //     if (!Utils.isBlank(selectorId)) {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: true,
    //             selector: "#" + selectorId,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }
    //     else {
    //         return {
    //             required: true,
    //             onsubmit: true,
    //             errorMessage: errorMessage,
    //             onchange: true,
    //             validated: (evt, ui) => {
    //                 if (ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").addClass("ig-valid-input");
    //                 else if (!ui.valid)
    //                     jQuery(evt.target).closest("ig-currency-editor").removeClass("ig-valid-input");
    //             }
    //         }
    //     }

    // }

    static addDays(date: Date, days: number): Date {
        date.setDate(date.getDate() + days);
        return date;
    }

    static getOdataStringForStringFilterType(filterTypeId: number, columnname: string, value: string) {
        if (filterTypeId == StringFilterType.Contain) {
            return "indexof(tolower(" + columnname + "),'" + value.toLocaleLowerCase() + "') ge 0";
        }
        else if (filterTypeId == StringFilterType.EndsWith) {
            return "endswith(tolower(" + columnname + "),'" + value.toLocaleLowerCase() + "') eq true";
        }
        else if (filterTypeId == StringFilterType.Equals) {
            return "tolower(" + columnname + ") eq '" + value.toLocaleLowerCase() + "'";
        }
        else if (filterTypeId == StringFilterType.NotContain) {
            return "indexof(tolower(" + columnname + "),'" + value.toLocaleLowerCase() + "') eq -1";//ne -1
        }
        else if (filterTypeId == StringFilterType.NotEqual) {
            return "tolower(" + columnname + ") ne '" + value.toLocaleLowerCase() + "'";
        }
        else if (filterTypeId == StringFilterType.StartWith) {
            return "startswith(tolower(" + columnname + "),'" + value.toLocaleLowerCase() + "') eq true";
        }
    }


    static getOdataStringForNumericFilterType(filterTypeId: number, columnname: string, value: string) {
        if (filterTypeId == NumericFilterType.Equals) {
            return columnname + " eq " + value;
        }
        else if (filterTypeId == NumericFilterType.GreaterThan) {
            return columnname + " gt " + value;
        }
        else if (filterTypeId == NumericFilterType.GreaterThanEqual) {
            return columnname + " ge " + value;
        }
        else if (filterTypeId == NumericFilterType.LessThan) {
            return columnname + " lt " + value;
        }
        else if (filterTypeId == NumericFilterType.LessThanEqual) {
            return columnname + " le " + value;
        }
        else if (filterTypeId == NumericFilterType.NotEqual) {
            return columnname + " ne " + value;
        }
    }

    static getOdataStringForDateFilterType(filterTypeId: number, columnname: string, value: string) {
        if (filterTypeId == DateFilterType.After) {
            return columnname + " ge " + value + "";
        }
        else if (filterTypeId == DateFilterType.Before) {
            return columnname + " le " + value + "";
        }
    }

    // static igValidatorIsValid(id: string): boolean {
    //     return jQuery("#" + id).igValidator("isValid");
    // }



    // static iggridEffectiveDateValidation(perIsRequire: boolean, perErrorMessage: string, igGridWidgetID: string): object {
    //     return {
    //         required: perIsRequire,
    //         errorMessage: perErrorMessage,
    //         onblur: true,
    //         onsubmit: true,
    //         // this property use for custom validation.
    //         custom: {
    //             method: (value, fieldOptions): boolean => {
    //                 let termDateCell = jQuery("#" + igGridWidgetID).igGridUpdating("editorForKey", "TermDate");
    //                 let termDateValue = jQuery(termDateCell).igDatePicker("value");
    //                 if (!Utils.isBlank(termDateValue) && !Utils.isBlank(value)) {
    //                     if (value > termDateValue) {
    //                         return false;
    //                     }
    //                     else {
    //                         return true;
    //                     }
    //                 }
    //                 else {
    //                     return true;
    //                 }
    //             },
    //             errorMessage: AppConstant.effectiveDateMessage
    //         }
    //     }
    // }

    // static iggridTermDateValidation(igGridWidgetID: string): object {
    //     return {
    //         onsubmit: true,
    //         custom: {
    //             method: (value, fieldOptions): boolean => {
    //                 let effectiveDateCell = jQuery("#" + igGridWidgetID).igGridUpdating("editorForKey", "EffectiveDate");
    //                 let effectiveDateValue = jQuery(effectiveDateCell).igDatePicker("value");
    //                 if (!Utils.isBlank(effectiveDateValue) && !Utils.isBlank(value)) {
    //                     if (value < effectiveDateValue) {
    //                         return false;
    //                     }
    //                     else {
    //                         return true;
    //                     }
    //                 }
    //                 else {
    //                     return true;
    //                 }
    //             },
    //             errorMessage: AppConstant.termDateMessage
    //         }
    //     }
    // }

    // static createIgTextRequire(errorMessage: string, selectorId?: string): object {
    //     return {
    //         required: true,
    //         onsubmit: true,
    //         errorMessage: errorMessage,
    //         onchange: true,
    //         selector: "#" + selectorId,
    //         validated: (evt, ui) => {
    //             if (ui.valid)
    //                 jQuery(evt.target).closest("ig-text-editor").addClass("ig-valid-input");
    //             else if (!ui.valid)
    //                 jQuery(evt.target).closest("ig-text-editor").removeClass("ig-valid-input");
    //         }
    //     }
    // }

    static printPage(el: any, isSpecifiDiv?: boolean): void {
        if (isSpecifiDiv) {
            let html: any = '<HTML>\n<HEAD>\n';
            localStorage.setItem('htmlElement', html);
            let headTags = document.getElementsByTagName("head");
            let headhtml: any = headTags[0].innerHTML;
            headhtml += '\n</HE' + 'AD>\n<BODY onload="window.print();window.close()">\n';
            localStorage.setItem('headHtmlElement', headhtml);
            let specificDivElement = document.getElementById(el);
            let specificDivhtml: any = specificDivElement.innerHTML;
            specificDivhtml += '\n</BO' + 'DY>\n</HT' + 'ML>';
            localStorage.setItem('specificDivHtmlElement', specificDivhtml);
            var printWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
            printWin.document.open();
            printWin.document.write(localStorage.getItem('htmlElement').toString() + '' + localStorage.getItem('headHtmlElement').toString() + '' + localStorage.getItem('specificDivHtmlElement').toString());
            printWin.document.close();
            localStorage.removeItem('htmlElement');
            localStorage.removeItem('headHtmlElement');
            localStorage.removeItem('specificDivHtmlElement');
        }
        else {
            window.print();
        }
    }

    static formateDate(value: Date): Date {
        if (Utils.isBlank(value)) {
            return value;
        }
        else {
            let formattedDate = moment(value).format("YYYY-MM-DD");
            return new Date(formattedDate);
        }
    }
    static formateDatetime(value: string): string {
        let formattedDate = moment(value).format();
        return formattedDate;
    }
    static formateDatewithformat(value: string, format?: string): string {
        let formattedDate;
        if (!!(format)) { formattedDate = moment(value).format(format); }
        else { formattedDate = moment(value).format("DD-MM-YYYY"); }
        return formattedDate;
    }

    static blankIfNull(value: string): string {
        if (value == null || value == undefined) {
            return '';
        }
        else {
            return value;
        }
    }
    //Do not use this now (Tej - 12/28/2017)
    //static compareDates(date: Date, fromDate: Date, toDate: Date): boolean {
    //    let date1 = moment(date).format("YYYY-MM-DD");
    //    let date2 = moment.utc(fromDate).format("YYYY-MM-DD");
    //    let date3 = moment.utc(toDate).format("YYYY-MM-DD");
    //    let result = moment(date1).isBetween(date2, date3, null, '[]');
    //    return result;
    //}


    static businessDateValidationMessage(dateType: string, dynamicPage: string): string {
        return dateType + " date should be between " + dynamicPage + " effective and term date";
    }

    // static isGridEditing(selectorID: string): boolean {
    //     return jQuery("#" + selectorID).igGridUpdating("isEditing");
    // }

    // Static Property With Static Value
    static listHours: Array<KeyValModel> = [{ key: 1, value: "01" }, { key: 2, value: "02" }, { key: 3, value: "03" }, { key: 4, value: "04" }, { key: 5, value: "05" }, { key: 6, value: "06" }, { key: 7, value: "07" }, { key: 8, value: "08" }, { key: 9, value: "09" }, { key: 10, value: "10" }, { key: 11, value: "11" }, { key: 12, value: "12" }, { key: 13, value: "13" }, { key: 14, value: "14" }, { key: 15, value: "15" }, { key: 16, value: "16" }, { key: 17, value: "17" }, { key: 18, value: "18" }, { key: 19, value: "19" }, { key: 20, value: "20" }, { key: 21, value: "21" }, { key: 22, value: "22" }, { key: 23, value: "23" }, { key: 24, value: "24" }];

    static listDays: Array<KeyValModel> = [{ key: 1, value: "01" }, { key: 2, value: "02" }, { key: 3, value: "03" }, { key: 4, value: "04" }, { key: 5, value: "05" }, { key: 6, value: "06" }, { key: 7, value: "07" }, { key: 8, value: "08" }, { key: 9, value: "09" }, { key: 10, value: "10" }, { key: 11, value: "11" }, { key: 12, value: "12" }, { key: 13, value: "13" }, { key: 14, value: "14" }, { key: 15, value: "15" }, { key: 16, value: "16" }, { key: 17, value: "17" }, { key: 18, value: "18" }, { key: 19, value: "19" }, { key: 20, value: "20" }, { key: 21, value: "21" }, { key: 22, value: "22" }, { key: 23, value: "23" }, { key: 24, value: "24" }, { key: 25, value: "25" }, { key: 26, value: "26" }, { key: 27, value: "27" }, { key: 28, value: "28" }, { key: 29, value: "29" }, { key: 30, value: "30" }, { key: 31, value: "31" }];

    static validateNPI(npi: string): boolean {
        if (npi) {
            let NPI = npi;
            if (NPI.length == 10) {
                NPI = NPI.slice(0, 9);
                let GetOddNPInum = [];// store Odd position number
                let GetEvenNPInum = [];// store even position number
                //Temp Varialble
                let sum: number = 0;
                let ODDnum: number = 0;
                let GetEvenNPI = 1;
                //end
                for (var i = 0; i < 5; i++) {
                    let ODDNPI: any = NPI[ODDnum];
                    ODDNPI = ODDNPI * 2;
                    let oddsum: number = ODDNPI.toString().length;
                    var temp1 = 0;
                    for (var j = 0; j < oddsum; j++) {
                        var getsum = ODDNPI.toString()[j];
                        temp1 = parseInt(getsum) + temp1;
                    }
                    GetOddNPInum.push({ NUM: temp1 });
                    ODDnum = ODDnum + 2;
                    let EvenNPI: any = NPI[GetEvenNPI];
                    EvenNPI = EvenNPI * 1;
                    GetEvenNPInum.push({ Evennum: EvenNPI });
                    GetEvenNPI = GetEvenNPI + 2;
                }

                for (var k = 0; k <= 3; k++) {
                    sum = GetOddNPInum[k].NUM + GetEvenNPInum[k].Evennum + sum;
                }
                var appendValue = 24 + sum + GetOddNPInum[4].NUM;
                if ((appendValue % 10) == 0) {
                    NPI = NPI + "0";
                }
                else {
                    var Tempdata = appendValue % 10;
                    Tempdata = 10 - Tempdata;
                    NPI = NPI + Tempdata;
                }
                var GetNPINumber = npi;
                if (NPI != GetNPINumber) {
                    return true;
                } else {
                    //return false;
                }
            } else {
                return true;
            }
        }
        else {
            //return false;
        }
    };


    //gaurav
    static isJson(value: string) {
        var isJson = false;
        try {
            //This works with JSON string and JSON object, not sure about others.
            var json = JSON.parse(value);
            isJson = (typeof (json) === 'object')
        }
        catch (ex) { }
        return isJson;
    }

    //     static isJson(value: string) {
    //         var isJson = false;
    //         try {
    //             //This works with JSON string and JSON object, not sure about others.
    //             var json = jQuery.parseJSON(value);
    //             isJson = (typeof (json) === 'object')
    //         }
    //         catch (ex) { }
    // return isJson;
    //     }

    // static getSystemSettings<T>(arg: T, localStoreManager: LocalStoreManagerService, settingCode: string): any {
    //     let systemSettingList: Array<SystemSettingModel> = localStoreManager.getDataObject<SystemSettingModel[]>(DBkeys.SYSTEM_SETTINGS);
    //     switch (settingCode) {
    //         case SystemSetting.MemNameFormat.toLocaleString(): {
    //             let stringValue = systemSettingList.find(e => e.settingCode == SystemSetting.MemNameFormat.toLocaleString()).stringValue
    //             return stringValue.replace("FirstName", arg["firstName"]).replace("LastName", arg["lastName"]).replace("MiddleName", arg["middleName"]).replace("Prefix", arg["prefix"]).replace("Suffix", arg["suffix"]).replace(/\+'/g, "").replace(/'\+/g, "");
    //         }
    //         case SystemSetting.ProvNameFormat.toLocaleString(): {
    //             let stringValue = systemSettingList.find(e => e.settingCode == SystemSetting.ProvNameFormat.toLocaleString()).stringValue
    //             return stringValue.replace("FirstName", arg["firstName"]).replace("LastName", arg["lastName"]).replace("MiddleName", arg["middleName"]).replace("Title", arg["title"]).replace("Suffix", arg["suffix"]).replace("Prefix", arg["prefix"]).replace(/\+'/g, "").replace(/'\+/g, "");
    //         }
    //         default: {
    //             return null;
    //         }
    //     }
    // }

    static getStringFilterEnumValue(filterID: number) {
        if (filterID == StringFilterType.Contain) {
            return 'contain';
        }
        else if (filterID == StringFilterType.EndsWith) {
            return 'ends with';
        }
        else if (filterID == StringFilterType.Equals) {
            return 'equals';
        }
        else if (filterID == StringFilterType.NotContain) {
            return 'not contain';
        }
        else if (filterID == StringFilterType.NotEqual) {
            return 'not equal';
        }
        else if (filterID == StringFilterType.StartWith) {
            return 'start with';
        }
    }

    static getNumberFilterEnumValue(filterID: number) {
        if (filterID == NumericFilterType.Equals) {
            return 'equals';
        }
        else if (filterID == NumericFilterType.NotEqual) {
            return 'not equal';
        }
        else if (filterID == NumericFilterType.GreaterThan) {
            return 'greater than';
        }
        else if (filterID == NumericFilterType.LessThan) {
            return 'less than';
        }
        else if (filterID == NumericFilterType.GreaterThanEqual) {
            return 'greater than or equal to';
        }
        else if (filterID == NumericFilterType.LessThanEqual) {
            return 'less than or equal to';
        }
    }

    static getRecordStatus(effectiveDate: Date, termDate: Date): RecordStatus {
        let dateString: string = new Date().toLocaleDateString();
        let currentDate: Date = new Date(dateString);
        if (effectiveDate.toLocaleDateString() == termDate.toLocaleDateString())
            return RecordStatus.VoidOrInvalid;
        else if (currentDate < effectiveDate)
            return RecordStatus.InActive;
        else if (currentDate >= effectiveDate && currentDate <= termDate)
            return RecordStatus.Active;
        else if (currentDate > termDate)
            return RecordStatus.Termed;
        else return RecordStatus.Pend;
    }

    static ageTillCurrentDate(dob: Date): number {

        let currentDate = new Date();
        let todayYear = currentDate.getFullYear();
        let todayMonth = currentDate.getMonth();
        let todayDay = currentDate.getDate();
        let formatedDOB = this.setDate(dob);
        let age = todayYear - formatedDOB.getFullYear();

        if (todayMonth < formatedDOB.getMonth() - 1) {
            age--;
        }

        if (formatedDOB.getMonth() - 1 === todayMonth && todayDay < formatedDOB.getDate()) {
            age--;
        }
        return age;
    }

    static isMbiNumberValid(mbiNumber: string): boolean {
        let isMbiValid: boolean = false;
        if (!Utils.isBlank(mbiNumber)) {
            let MBI_REGEXP: RegExp = /\b[1-9][AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y]{2}\d{2}\b/gm
            if (MBI_REGEXP.test(mbiNumber)) {
                isMbiValid = true;
            }
        }
        return isMbiValid;
    }

    static identityApiListToRedirectCall(): string[] {
        return ["api/account", "api/RoleTypeClaims", "api/ClientManagement", "api/Menu"]
    }

    //Adit
    static camelizeString(str) {
        return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index) {
          return index === 0 ? word.toLowerCase() : word.toUpperCase();
        }).replace(/\s+/g, '');
      }

}

export class Encryptions {

    //Encrypt the Passwort with Base64
    static key = "#AANEEL@@HPS@@KEY@2017#";

    static encrypt(value: string): string {
        //Impementing the Key and IV and encrypt the data
        return CryptoJS.AES.encrypt(value, this.key).toString();
    }

    static decrypt(value: string): string {
        //Impementing the Key and IV and decrypt the data
        return CryptoJS.AES.decrypt(value, this.key).toString(CryptoJS.enc.Utf8);
    }
}

//Extension 
declare global {
    interface Date {
        toJSON(): void;
        //formatDate(): Date;
    }
}

Date.prototype.toJSON = function () { return moment(this).format("YYYY-MM-DD"); }
//Date.prototype.formatDate = function () {
//    if (Utils.isBlank(this)) {
//        return this;
//    }
//    else {
//        return moment.utc(this).format("YYYY-MM-DD");
//        //return new Date(formattedDate);
//    }
//}



