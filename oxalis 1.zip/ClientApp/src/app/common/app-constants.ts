export class AppConstant {

    //#region Identity server
    public static identityUnavailable = 'Authorization server unavailable! Please contact the administrator.';
    public static identityDeniedMessage = 'Access denied from authorization server! Please allow required permission to access client application.';
    public static identityInValidConfig = 'Client configuration invalid! Please contact the administrator.';
    public static identityNetworkError = 'Network Error';
    public static identityInvalidSecret = "invalid_client";
    public static linkUserSuccessMsg = "User linked Successfully.";
    public static unauthorizeRedirection = 'Session is expired, Please Login again!';
    public static createPassword = "Registration Successful. E-mail has been sent to registered user.";
    public static linkUserMsg = "User is already link with other clients, Do you want to link user to your client?";
    public static disableAccount = "Your account is not yet active, please allow up to 72 hours for your access to be enabled.";
    public static inProgressRequest = "Your request is in progress, Admin will contact you soon!";
    public static clientAccess = 'You do not have rights to access {{clientName}}.'

    static deleteMessage: string = 'Are you sure you want to delete?';
    static confirmDeleteMessage: string = 'Record will be removed permanently. Are you sure to remove?';
    static effectiveDateMessage: string = 'Effective date less than Term date.';
    static termDateMessage: string = 'Term date must be greater than Effective date.';
    static saveSuccessMessage: string = 'Record Saved Successfully.';
    static credSuccessMessage: string = 'Saved Successfully.';
    static enterValidMBI: string = 'Please Enter Valid MBI';
    static updateSuccessMessage: string = 'Record Updated Successfully.';
    static noEnrollment: string = 'There is no Enrollment Transaction.';
    static cantEnroll: string = 'There is no Disenrollment or Cancellation of Enrollment Transaction received for this Member';
    static effDatePrior: string = 'Effective date of the transaction should not be prior to the Enrollment 61 transaction’s Effective date.';
    static noDisEnroll: string = 'There is no Disenrollment Transaction received for this Member';
    static actionsConfiguredSuccess: string = 'Actions Configured Successfully for Selected TRC';
    static invalidProvider: string = 'Please select a valid PCP';
    static addMemberInfo: string = 'Please Add Member Information.';
    static addProviderInfo: string = 'Please Add Billing Provider Information.';
    static referProviderNpi: string = 'Please Select Referring Provider NPI.';
    static notesAttachmentSuccess: string = 'Notes & Attachments Attached Successfully';
    static attachmentUploadSuccess: string = 'Attachments Added Successfully';
    static fileDataError: string = 'Error in getting File Data';
    static ExportError: string = 'Error in Exporting data';
    static noFileInfo: string = 'File data not available';
    static NotesAdded: string = 'Notes Added Successfully';
    static selectMember: string = 'Please First Select Member';
    static invalidMember: string = 'Please select a valid member';
    static applyFilter: string = 'Please Apply Filter';
    static NotesError: string = 'Error in Saving Note';
    static NotesContentLength: string = 'Note must be less than 250 characters';
    static fileUploadError: string = 'Error in Attaching Notes & Attachment';
    static UploadAttachment: string = 'Please Upload Attachment';
    static selectAttachmentType: string = 'Please Select Attachment Type';
    static enterMemberId: string = 'Please Enter MemberId';
    static wentWrong: string = 'Something Went Wrong';
    static selectContract: string = 'Please Select ContractId';
    static selectAction: string = 'Please Select Action';
    static selectPbp: string = 'Please Select PbpId';
    static documentDeleted: string = 'Attachment deleted Successfully';
    static claimAdjudicated: string = 'Claim has been adjudicated successfully';
    static claimFileDeleted: string = 'Claim File deleted Successfully';
    static NoteDeleted: string = 'Note deleted Successfully';
    static deleteSuccessMessage: string = 'Record Deleted Successfully.';
    static salutationGenderMisMatch: string = 'Salutation & Gender Mismatch';
    static deleteConfirmationMessage = 'Are you sure you want to delete this record?';
    static deleteConfirmationTitle = 'Delete Confirmation';
    static textYesConfirm = 'Yes';
    static textNoConfirm = 'No';
    static textOkConfirm = 'Ok';
    static deleteConfirmationProblemMessageWithID = 'Are you sure you want to delete {{id}} record?';
    static deleteConfirmationProblemMessageWithName = 'Are you sure you want to delete {{name}}?';
    static errorMessage: string = 'Server Error !';
    static selectRecordMessage: string = 'Please select one record !';
    static notMappedStandardCodeMessage: string = 'Homegrown codes not mapped to standard codes may cause issues in system processes and reporting';
    static termSuccessMessage: string = 'Record Termed Successfully.';
    static confirmTermMessage: string = 'Associated entities will also get Termed. Are you sure to Term?';
    static accessDeniedMessage: string = "Access Denied";
    static homeGroundCodeTerminated: string = 'Attached Home grown Codes will be terminated';
    static revenueCodeRequired: string = 'Please Enter Revenue Code';
    static payableAmountNegative: string = 'Allowed Amount must be Greater than Summation of Copay,Coinsurance,NonCoveredAmount,DeductibleAmount';
    static claimEditDenied: string = "Claim edit denied. Kindly check";
    static procedureCodeRequired: string = 'Please Enter Procedure Code';
    static benifitTerminateMessage: string = 'Benefit termed successfully';
    static planTerminateMessage: string = 'Plan termed successfully';
    static standardCodeMessage: string = 'Do you wish to proceed without attaching to a standard code?';
    static existsHomeGrownCode: string = 'Home grown code already exists.Do you want to continue?';
    static wantContinue: string = 'Do you want to continue?';
    static priorityChanged: string = 'Priority Changed Successfully';
    static loading: string = 'Loading , Attempting to fix';
    static enterCode: string = 'Please enter Code(s)';
    static benefitAddedToPlan: string = 'Benefit(s) added successfully to the Plan';
    static preEnrollmentConfirmation = 'Fields are mandatory and must be updated to continue';
    static uploadAttachment = 'Please Upload  Attachment';
    static preEnrollmentSuccessMsg = 'Member Id {{memberId}} created successfully. Do you wish to continue to Enrollment screen?';
    static preEnrollmentMemberExistsMsg = 'Record already exists for the provided MBI and the System Member Id is {{memberId}}. Would you like to continue to Enrollment screen to make any changes?'
    static saveMessageForEnrollment: string = 'Record submitted successfully and Member Id is {{memberId}}';
    // static updateMessageForEnrollment: string = 'Record Updated Successfully and Member Id is {{memberId}}';
    // static effectiveDateError :string='Home grown code effective date must be between standard code effective date and standard code term date.';
    // static termDateError : string='Home grown code term date must be less than or equal to standard Code term date';
    static contractTerminateMessage: string = 'Contract termed successfully';
    static termTerminateMessage: string = 'Term termed successfully';
    static beqFileGenerateMessage: string = 'BEQ file successfully generated for {{id}} Records';
    static fileGenerationemssage: string = 'File Generated Successfully';
    static noRecordsFound: string = 'No records found';
    static selectTrc: string = 'Please Select TRC, Contract & Pbp to Configure Plan Actions';
    static noInvoiceFound: string = 'No Invoice Found';
    static noPaymentFound: string = 'No Payment Found';
    static tranNotCreated: string = 'Transaction Details Not Created';
    static saveWithoutTran: string = 'Do You Want to Save Without Transaction?';
    static noPremiumAccountFound: string = 'No Premium Account Found';
    static noMemberFound: string = 'No Member Found';
    static enrollmentNotExistMessage: string = 'Verify Pre-enrollment and continue with Enrollment or Add New Enrollment';
    static CMSFileNotExistMessage: string = 'File data has been not found';
    static textLinkUser = 'Link User';
    static textBack = 'Back';
    static existsCodeUsed = 'Record has not been deleted becuase it\'s used in another places. Please check below list. ';
    static acceptRequest = 'Request has been successfully Accepeted.';
    static rejectRequest = 'Request has been successfully Rejected.';
    static transationStatusValidation = 'This application did not go through BEQ Process, initiate BEQ before CMS Submission';
    //#endregion


    //#region DBKeys
    public static readonly CURRENT_USER = "current_user";
    public static readonly USER_PERMISSIONS = "user_permissions";
    public static readonly ACCESS_TOKEN = "access_token";
    public static readonly REFRESH_TOKEN = "refresh_token";
    public static readonly TOKEN_EXPIRES_IN = "expires_in";
    public static readonly ID_TOKEN = "id_token";
    public static readonly IS_CLIENTACCESS = "is_clientaccess";
    public static readonly REDIRECT_LOGIN_URL = "redirect_login_url";

    public static readonly REMEMBER_ME = "remember_me";

    public static readonly LANGUAGE = "language";
    public static readonly HOME_URL = "home_url";
    public static readonly SYSTEM_SETTINGS = "system_settings";
    //#endregion

    //#region permission
    static readonly viewSectionPermission = "You dont have permission to view this section";
    static readonly viewSectionManagePermission = "You dont have permission to manage this section";
    static readonly addOperation = 'create';
    static readonly editOperation = 'edit';
    static readonly viewOperation = 'view';
    //#endregion

    //#region common
    static readonly deBounceTime = 300;
    static readonly defaultPageSize: number = 10;
    static readonly defaultToasterTimeout: number = 5000;
    static readonly defaultChukSize: 20;
    static readonly viewPageSize: number = 5;
    static readonly isDevelopmentEnvironment = document.location.hostname.indexOf('localhost') > -1 ? true : false;
    static readonly loadOnDemandPageSize: number = 25;
    static readonly tieredCapitationType: number = 8604;
    static previousURL: string = '';
    static readonly defaultMinAge: number = 0;
    static readonly defaultMaxAge: number = 150;
    static readonly defaultEligibleMonths: number = 0;
    static readonly defaultGender: string = 'B';
    public static comboOptionMismatchFound = 'No matches found';
    static readonly companyUrl = 'api/Organization/GetCompanyForDDL';
    static readonly stateUrl = 'api/ZipCode/GetStates';
    static readonly productTypeUrl = 'api/ProductType/GetKeyValue';
    static readonly approvalStatusUrl = 'api/CommonCode/71/0';
    static readonly enterValidMinCode = 'Please enter a valid  Min code';
    static readonly enterValidMaxCode = 'Please enter a valid Max code';
    static readonly maximumAllowedCode = "Maximum 16 characters allowed";
    static readonly daysConfiguration = 1;
    static fillMandatoryMessage: string = 'Please fill all the Mandatory Fields';
    //#endregion

    //#region IPA
    static readonly ipaAddedMessage = "IPA Information added successfully";
    static readonly ipaUpdatedMessage = "IPA Information updated successfully";
    static readonly mbiValidationMessage = "MBI is not in valid format, Do you want to modify?";
    //#endregion

    //#region Administration constants
    static readonly includeInMaxOopIn = "Please select any include in max oop for in network";
    static readonly plsSelectFile = "Please select file to Export";
    static readonly includeInMaxOopOut = "Please select any include in max oop for out network";
    static readonly providerNotFount = "{{provider}} not found";
    static readonly groupId = "Group ID";
    static readonly npi = "NPI";
    static readonly providerId = "Provider ID";
    static readonly tax = "Tax";
    static readonly npiLengthValidationMessage = "NPI must be at least 10 digit long and not more than 10 digit";
    static readonly taxLengthValidationMessage = "Tax must be at least 9 digit long and not more than 9 digit";

    static readonly dobDateValidationMessage = "DOB is less than Receipt Date,Signature Date,Medicare Part A Effective Date,Medicare Part B Effective Date,Medicare Part D Effective Date";
    static readonly mPAEffDateValidationMessage = "Medicare Part A Effective Date can be greater than 3 months only from today's date, Do you wish to continue?";
    static readonly mPBEffDateValidationMessage = "Medicare Part B Effective Date can be greater than 3 months only from today's date, Do you wish to continue?";
    static readonly checkLessMPAEffDateValidation = "Medicare Part B Effective Date should not be less than Medicare Part A Effective Date, Do you wish to continue?";
    static readonly medicarePartAConfirmation = "Medicare Part A EffDate Confirmation";
    static readonly medicarePartBConfirmation = "Medicare Part B EffDate Confirmation";
    static readonly saleDateValidation = "Sale Date should not be greater than Receipt Date and Signature Date";
    static readonly effectiveConfirmation = "Effective Date Confirmation";
    static readonly termConfirmation = "Term Date Confirmation";
    static readonly effectiveDateValidation = "Effective Date should be prior to today's date, Do you wish to continue?";
    static readonly transEffectiveDateValidation = "Effective Date cannot be prior to Part A,B,D, and receipt/Signature date";
    static readonly termDateValidation = "Term Date should be prior to today's date, Do you wish to continue?";
    static readonly emergencyPhoneConfirmation = "Emergency Contact Phone and Phone Number Confirmation";
    static readonly emergencyAltPhoneConfirmation = "Emergency Contact Phone and Alt Phone Number Confirmation";
    static readonly emergencyContactPValidation = "Emergency Contact Phone and Phone Number are same";
    static readonly emergencyContactAValidation = "Emergency Contact Phone and Alt Phone Number are same";
    static readonly submitRecordMessage = "Please fill all mandatory fields"
    static readonly BEQValidationMessage = "This application did not go through BEQ Process, initiate BEQ before CMS Submission"

    static readonly primarySpecialtyDeleteInfo = "Please make other specialty as primary to delete this.";
    static readonly displayOrderUpdateMessage = "Display order updated successfully.";
    static readonly contactMailValueMessage = "Do you wish to remove Mail from contact preference?";
    static readonly DELETED_RECORD_CSSCLASS: string = 'deleted-record';

    //#region DefaultRoles
    static readonly newUser = "New User";
    //#endregion

    //#region
    static userRegisterTab = 'Registered Users';
    static userUnRegisterTab = 'Un-Registered Users';
    //#endregion
}


export class ShortcutKeys {
    public static readonly NEW_RECORD: string = 'alt+n';
    public static readonly LIST_PAGE_NEW_RECORD: string = 'ctrl+alt+n';
    public static readonly NEW_RECORD_CANCEL: string = 'esc';
    public static readonly TAB_NEXT: string = 'alt+right';
    public static readonly TAB_PREVIOUS: string = 'alt+left';
    public static readonly IGGRID_ADD_EDIT_ROW_TRIGGERS: string = 'F2,enter,click';
    public static readonly LIST_PAGE_EDIT_RECORD: string = 'ctrl+alt+e';
}


export class SQLDataTypeMaxValue {
    static money: number = 922337203685477.5;
}