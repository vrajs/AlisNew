import { BaseModel } from "../../common/base.model";

export class CapitationHeaderModel extends BaseModel {
    capitationHeaderId: number;
    capitationName: string;
    capitationCode: string;
    capitationTypeId: number;
    capitationDescription: string;
    effectiveDate: Date;
    termDate: Date;
    constructor() {
        super();
        this.capitationHeaderId = 0;
        this.capitationDescription = '';
    }
}