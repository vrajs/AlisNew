export class AnesConversionFactorModel
{
    public anesConversionFactorId: number;
    public name: string;    
    public roundToId: number;
    public roundingPoint: number;
    public posCode: string;
    public noOfMinutePerUnit: number;
    public effectiveDate: Date;
    public termDate?: Date;
}
