export class FeeScheduleLimitModel {
    url?: string;
    feeScheduleLimitId: number;
    code: string;
    quantity: number;
    limitTypeId?: number | null | undefined;
    limitType: string;
    limitDuration: number;
    limitDurationTypeId?: number | null | undefined;
    limitDurationType: string;
    limitMax: number;
    limitMaxTypeId?: number | null | undefined;
    limitMaxType: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}


