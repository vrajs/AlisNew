export class AnesthesiaRegionRateModel {
    public anesthesiaRegionRateId: number;    
    public state: string;
    public stateFullName: string;

    public carrier: string;    
    public localityCode: string;    
    public area: string;    
    public rate: number;    
    public effectiveDate: Date;
    public termDate?: Date | undefined | null;
}
