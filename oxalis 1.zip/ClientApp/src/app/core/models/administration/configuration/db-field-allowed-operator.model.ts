export class DBFieldAllowedOperatorModel {
    public field: string;
    public description: string;
    public sqlOperator: string;
}
