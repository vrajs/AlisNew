export class BenefitCopayPerDiemModel {
    benefitCopayPerDiemId: number;
    benefitHeaderId: number;
    startDay:number;
    endDay: number;
    perDiem: number;
    effectiveDate : Date;
    termDate?: Date | null | undefined;
 }