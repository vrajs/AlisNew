export class HasTermConfigurationDataModel {
    hasCodeData: boolean = false;
    hasServiceGroupData: boolean = false;
    hasModifierData: boolean = false;
    hasDiagnosisData: boolean = false;
    hasPlaceOfServiceData: boolean = false;
    hasBillTypeData: boolean = false;
    hasLimitsData: boolean = false;
    hasPaymentData: boolean = false;
}