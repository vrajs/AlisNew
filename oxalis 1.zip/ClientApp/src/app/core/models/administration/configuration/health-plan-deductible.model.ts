export class HealthPlanDeductibleModel {
    healthPlanDeductibleId: number;
    healthPlanId: number;
    benefitHeaderId: number;
    deductibleTypeId: number;
    deductibleType: string;
    isApplyToNetwork: boolean;
    applyNetwork: string;
    incomePercentage: number;
    effectiveDate: Date;
    termDate: Date;
}