import { BaseModel } from '@app/core/models';

export class BenefitServiceGroupModel extends BaseModel {
    benefitServiceGroupId: number;
    benefitHeaderId: number;
    clinicalCodeGroup: string;
    clinicalCodeGroupDetail: string;
    clinicalCodeGroupDetailId?: number;
    clinicalCodeGroupId?: number;
    clinicalCodeSubGroup: string;
    clinicalCodeSubGroupId?: number;
    isExclude: boolean = false;
    effectiveDate: Date;
    termDate?: Date | null | undefined;    
}
