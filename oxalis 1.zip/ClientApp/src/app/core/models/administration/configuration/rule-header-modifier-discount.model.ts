export class RuleHeaderModifierDiscountModel {
    public ruleHeaderModifierDiscountId: number;
    public ruleHeaderId: number;
    public modifierDiscountGroupId: number;
    public schedule: string;
    public effectiveDate: Date;
    public termDate?: Date;
}
