import { BaseModel } from "../../common/base.model";

export class TermFeeScheduleModel extends BaseModel {
    addedSource: string;
    claimServiceFeeSchedules: [];
    code: string;
    description: string;
    feeScheduleDetails: [];
    feeScheduleHeaderId: number;
    loadComment: string;
    providerContract: [];
    updatedSource: string;
    effectiveDate: Date;
    termDate: Date;
    termPayment: number[]
}