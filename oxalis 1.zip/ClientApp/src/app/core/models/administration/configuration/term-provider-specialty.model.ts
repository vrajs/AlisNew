import { BaseModel } from '@app/core/models';

export class TermProviderSpecialtyModel extends BaseModel{
    termProviderSpecialtyId: number;
    termHeaderId: number;
    specialtyId: number;
    specialtyName: string;
}