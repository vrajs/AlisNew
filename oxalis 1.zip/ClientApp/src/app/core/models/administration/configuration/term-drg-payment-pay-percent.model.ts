import { BaseModel } from "../../common/base.model";

export class TermDrgPaymentPayPercentModel extends BaseModel {
    drgPayPercentCode: string;
    drgPayPercentName: string;
    drgPaymentPayPercentId: number;
    termPayments: number[]
}