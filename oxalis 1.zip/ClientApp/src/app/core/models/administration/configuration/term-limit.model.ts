import { BaseModel, VisitCodeModel } from '@app/core/models'

export class TermLimitModel extends BaseModel {
    // visitCodeId: number;
    // code: string;
    // description: string;
    // visitTypeId: number;
    // visitType: string;
    // maxUnits?: number | null | undefined;
    // timePeriodId: number;
    // timePeriod: string;
    // benMaxUnit?: number | null | undefined;
    // beneMaxTimePeriodId?: string | null | undefined;
    // beneMaxTimePeriod: string;
    // isServiceOutsideUs: boolean = false;
    // maxAmount?: number | null | undefined;
    // effectiveDate: Date;
    // termDate?: Date | null | undefined;
    termLimitId: number;
    termHeaderId:number;
    visitCodeId: number;
    visitCode:Array<VisitCodeModel>;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}