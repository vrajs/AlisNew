import { BaseModel } from '@app/core/models';

export class BenefitVisitModel extends BaseModel {
    benefitVisitId: number;
    benefitHeaderId: number;
    visitCodeId: number;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
    shareBenefitHeaderId: any = [];
}

export class BenefitVisitLimitShareModel extends BaseModel{
    benefitVisitLimitShareId: number;
    benefitHeaderId: any = [];    
}
