import {  CopayCoinsuranceModel, BenefitHeaderModel } from '@app/core/models';

export class BenefitCopayCoinsuranceModel {
    benefitCopayCoinsuranceId: number;
    benefitHeaderId: number;
    copayCoinsuranceId : number;  
    effectiveDate : Date;
    termDate?: Date | null | undefined;
    copayCoinsurance?: CopayCoinsuranceModel | null | undefined;
    benefitHeader?: BenefitHeaderModel | null | undefined;

    constructor() {
        this.copayCoinsurance = new CopayCoinsuranceModel();
        this.benefitHeader = new BenefitHeaderModel();
    }
}
