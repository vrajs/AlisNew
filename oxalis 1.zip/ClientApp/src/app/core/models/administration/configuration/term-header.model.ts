import { BaseModel } from '@app/core/models';
import { TermProviderSpecialtyModel } from './term-provider-specialty.model';

export class TermHeaderModel extends BaseModel {
    termHeaderId: number;   
    termCode: string;
    termName: string;
    contractId: number;
    termDescription?: string | null | undefined;
    remitReason?: string | null | undefined;
    eobReason?: string | null | undefined;
    ageFrom: number;
    ageTo: number;
    gender: string;
    isAuthRequired: boolean = false;
    isAuthRequiredWhenBenefitRequireAuth: boolean = false;
    isCapitated: boolean = false;
    isDocumentRequired: boolean = false;
    isEmergencyRoom: boolean = false;
    isIgnoreCaseRate: boolean = false;
    isIgnoreFeeScheduleLimitIfAuthQuantityExceeds: boolean = false;
    isManualReview: boolean = false;
    isMembersAssigned: boolean = false;
    isPcp: boolean = false;    
    isUseFeeSchedule: boolean = false;
    effectiveDate: Date;
    termDate : Date | null | undefined;
    termProviderSpecialty: Array<TermProviderSpecialtyModel>;
    termProviderSpecialtyId: number[];

    constructor() {
        super();
        this.termProviderSpecialty = [];
    }
}



export class TerminateTermModel {
    id: number;
    termReason: string;
    termDate: Date;
}