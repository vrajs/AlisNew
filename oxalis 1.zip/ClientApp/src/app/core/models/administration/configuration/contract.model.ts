import { BaseModel } from "../..";

export class ContractModel extends BaseModel{
    anesConversionFactorCode:string;
    // anesConversionFactorId: number;
    capitationName: string;
    // capitationId: number;
    contractCode: string;
    contractDescription: string;
    contractHeaderId: number;
    contractName: string;
    claimType:string;
    // contractClaimType: Array<ContractCliamTypeModel>;
    // contractClaimId:number[];
    effectiveDate: Date;
    termDate?: Date;
    // contractId: number;
    // providerContract:[];
    // ruleHeaderFeeSchedules: [];
    // termHeader: [];

    // constructor() {
    //     super();
    //     this.contractClaimType = [];
    // }
}

export class ContractView {
    contractHeaderID: number;
    contractCode: string;
    contractName: string;
    contractDescription: string;
    claimType: string;
    capitationName: string;
    anesConversionFactorCode: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}

