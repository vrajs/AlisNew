import { BaseModel } from '@app/core/models';

export class DeductibleOopModel extends BaseModel {
    healthPlanDeductibleId: number;
    deductibleTypeId: number;

    familyDeductibleInNetwork: number | null | undefined;
    familyDeductibleOutNetwork: number | null | undefined;
    familyOopInNetwork: number | null | undefined;
    familyOopOutNetwork: number | null | undefined;

    incomePercentage?: number | undefined;    

    individualDeductibleInNetwork: number | null | undefined;
    individualDeductibleOutNetwork: number | null | undefined;
    individualOopInNetwork: number | null | undefined;
    individualOopOutNetwork: number | null | undefined;

    isApplyToNetwork: number;

    isApplyToOopAfterBenefitPricingInNetwork: boolean = false;
    isApplyToOopAfterBenefitPricingOutNetwork: boolean = false;    

    isCoinsuranceIncludeInMaxOopInNetwork: boolean = false;
    isCoinsuranceIncludeInMaxOopOutNetwork: boolean = false;
    isCopayIncludeInMaxOopInNetwork: boolean = false;
    isCopayIncludeInMaxOopOutNetwork: boolean = false;
    isDeductibleIncludeInMaxOopInNetwork: boolean = false;
    isDeductibleIncludeInMaxOopOutNetwork: boolean = false;

    isRollDeductibleAndOop: boolean = false;

    timePeriodIdInNetwork?: number | null | undefined;
    timePeriodIdOutNetwork?: number | null | undefined;

    effectiveDate: Date;
    termDate?: Date | null | undefined;   

    healthPlanId?: number;
    benefitHeaderId?: number;
    isIncludeInPlanDeductibleAndOop: boolean = false;
}
