import { BaseModel } from "../../common/base.model";

export class TermModel extends BaseModel {
    ageFrom: number;
    ageTo: number;
    contractCode: string;
    contractId: number;
    contractName: string;
    effectiveDate: Date;
    eobReason?: string | null | undefined;
    gender: string;
    remitReason?: string | null | undefined;
    specialtyName: string;
    termCode: string;
    termDate: Date | null | undefined;
    termDescription?: string | null | undefined;
    termHeaderId: number;
    termName: string;
}