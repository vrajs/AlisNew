import { BaseModel } from "@app/core/models"

export class OrganizationRuleModel extends BaseModel {        
    public ruleHeaderId: number;
    public companyId: number | null;
    public company: string | null;
    public subCompanyId: number | null;
    public subCompany: string | null;
    public lobid: number | null;
    public lob: string | null;
    public productTypeId: number | null;
    public productType: string | null;
    public healthPlanId: number | null;
    public healthPlan: string | null;
    public effectiveDate: Date;
    public termDate?: Date;

    constructor() {
        super();
        this.ruleHeaderId = 0;
    }
}
