export class HasPlanConfigurationData {
    hasBenefitData: boolean = false;    
    hasDeductibleMAXOOPData: boolean = false;
}