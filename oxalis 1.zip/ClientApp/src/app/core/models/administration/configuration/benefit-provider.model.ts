export class BenefitProviderModel {
    benefitProviderId: number;
    benefitHeaderId: number;
    identifierTypeId: number;
    identifierCode: string;  
    isExclude: boolean;
    effectiveDate : Date;
    termDate?: Date | null | undefined;
    identifierTypeName?: string | null
}
