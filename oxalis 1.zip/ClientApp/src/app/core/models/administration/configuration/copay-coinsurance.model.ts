export class CopayCoinsuranceModel {
    copayCoinsuranceId: number;
    copayCoinsuranceCode: string;
    fixedCopay?: number | null | undefined;
    maxCopay?: number | null | undefined;
    maxCopayTimePeriodId?: number | null | undefined;
    maxCopayTimePeriod: string;
    maxCopayPerDiem?: number | null | undefined;
    maxCopayPerDiemTimePeriodId?: number | null | undefined;
    maxCopayPerDiemTimePeriod: string;
    coinsurancePercentage?: number | null | undefined;
    isVariableCopayPerDiem: boolean;
    isParNonPar?: number | null | undefined;
    parNonPar: string;
    networkId?: number | null | undefined;
    network: string;
    isNoAuth: boolean;    
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}