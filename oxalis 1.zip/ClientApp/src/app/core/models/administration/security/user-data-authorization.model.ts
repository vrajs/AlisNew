export class UserDataAuthorizationModel{
        userID: string;        
        dataPreferenceByID: number | null
        dataPreferenceIDs: number[];
}