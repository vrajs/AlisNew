import { BaseModel } from "../../common/base.model";

export class LocationModel extends BaseModel {
    locationId: number;
    locationTypeId: number;
    locationTypeName: string;
    locationName: string;
    regionId: number;
    regionName: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    stateFullName: string;
    county: string;
    country: string;
    zip: string;
    phone: string;
    fax: string;
    emergencyPhone: string;
    secondaryPhone: string;
    primaryEmail: string;
    secondaryEmail: string;
    afterHoursCoverage: string;
    minimumAge: number;
    maximumAge: number;
    isHandicapAccessible: boolean;
    isPcp: boolean;
    isAcceptingNewPatient: boolean;
    isIncludeInProviderDirectory: boolean;
    genderRestriction: string;
    sundayFromHour: string;
    mondayFromHour: string;
    tuesdayFromHour: string;
    wednesdayFromHour: string;
    thursdayFromHour: string;
    fridayFromHour: string;
    saturdayFromHour: string;
    sundayToHour: string;
    mondayToHour: string;
    tuesdayToHour: string;
    wednesdayToHour: string;
    thursdayToHour: string;
    fridayToHour: string;
    saturdayToHour: string;

    sundayFromHourView: Date;
    mondayFromHourView: Date;
    tuesdayFromHourView: Date;
    wednesdayFromHourView: Date;
    thursdayFromHourView: Date;
    fridayFromHourView: Date;
    saturdayFromHourView: Date;
    sundayToHourView: Date;
    mondayToHourView: Date;
    tuesdayToHourView: Date;
    wednesdayToHourView: Date;
    thursdayToHourView: Date;
    fridayToHourView: Date;
    saturdayToHourView: Date;    
    effectiveDate: Date;
    termDate: Date | null | undefined;

    constructor() {
        super();
        this.address2 = '';
        this.city = '';
        this.state = '';
        this.stateFullName = '';
        this.county = '';
        this.country = '';
        this.zip = '';
        this.phone = '';
        this.fax = '';
        this.emergencyPhone = '';
        this.secondaryPhone = '';
        this.primaryEmail = '';
        this.secondaryEmail = '';
        this.afterHoursCoverage = '';
        this.genderRestriction = '';
        this.sundayFromHourView = void 0;
        this.mondayFromHourView = void 0;
        this.tuesdayFromHourView = void 0;
        this.wednesdayFromHourView = void 0;
        this.thursdayFromHourView = void 0;
        this.fridayFromHourView = void 0;
        this.saturdayFromHourView = void 0;
        this.sundayToHourView = void 0;
        this.mondayToHourView = void 0;
        this.tuesdayToHourView = void 0;
        this.wednesdayToHourView = void 0;
        this.thursdayToHourView = void 0;
        this.fridayToHourView = void 0;
        this.saturdayToHourView = void 0;
    }
}

export class TerminateLocationModel {
    id: number;
    termReason: string;
    termDate: Date;
}
