export class TimelyFilingModel {    
    timelyFilingId: number;   
    description: string;
    providerStatusId: number;
    providerStatusName: string;
    providerTypeId: number;
    providerTypeName: string;
    days: number;    
    effectiveDate: Date;  
    termDate?: Date | null | undefined;
}
