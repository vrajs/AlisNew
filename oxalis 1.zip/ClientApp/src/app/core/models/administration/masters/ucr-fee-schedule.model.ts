export class FeeScheduleHeaderModel {
    feeScheduleHeaderId: number;
    code: string;
    description: string;
    effectiveDate: Date; 
    termDate?: Date | null | undefined;
    feeScheduleDetailRate?: number | null;
}

export class FeeScheduleDetailModel {    
    public feeScheduleDetailId: number;    
    public code: string;    
    public modifier1: string;    
    public modifier2: string;    
    public rate: number;    
    public posCode: string;
    public ageFrom: number;
    public ageTo: number;
    public providerTypeId: number;
    public providerSpecialtyId: number;    
    public additionalRequirement: string;    
    public maxUnits: number;
    public shareLimitId: number;    
    public rural: string;    
    public comment: string;    
    public effectiveDate: Date;
    public termDate?: Date | undefined | null;
    public feeScheduleHeaderId: number;
    public feeScheduleLimitId: number;
    public clinicalCodeTypeId: number;
}
