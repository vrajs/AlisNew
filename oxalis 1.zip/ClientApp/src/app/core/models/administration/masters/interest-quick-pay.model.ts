export class InterestQuickPayModel {
    interestQuickPayId: number;
    isQuickPay: boolean;
    isEdi: boolean;
    schedule: string;
    description: string;
    fromDay: number;
    toDay: number;
    rate: number;
    effectiveDate: Date;
    termDate?: Date | null | undefined;

    constructor() {
        this.isQuickPay = true;
    }
}
