export class SpecialtyModel {
    constructor() {
        this.specialtyID = 0;
    }
    specialtyID: number;
    specialtyCode: string;
    cMSCode: string;
    specialtyName: string;
    effectiveDate: string;
    termDate: string;
}