import { BaseModel } from "@app/core/models";

export class ClinicalCodeGroupDetailModel extends BaseModel {
    public clinicalCodeGroupDetailId : number;
    public groupTypeId : number;
    public clinicalCodeSubGroupId : number;
    public  clinicalCodeSubGroup : string;
    public subCategoryName : string;
    public clinicalCodeTypeId : number ;  
    public clinicalCodeType : string;
    public  startCode : string;
    public endCode  : string;
     public excludeStartCode : string;   
     public excludeEndCode : string;  
     public effectiveDate : string;
     public termDate : string | null;
     public isAuth : boolean = false;
}