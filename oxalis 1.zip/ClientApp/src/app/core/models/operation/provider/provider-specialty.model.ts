import { SpecialtyModel } from "../../administration/masters/specialty.model";


export class ProviderSpecialtyModel {
    constructor() {
        this.specialty= null;
    }
    providerSpecialtyId: number;
    providerId: number;
    specialtyId: number;
    isPrimarySpecialty: boolean = false;
    effectiveDate: Date;
    termDate: Date; 
    specialty: SpecialtyModel;   
}