export class ProviderStatus {
    statusId: number;
    providerStatusId: number | null;
    lobId: number | null;
    groupId: number | null;
    address: string;
    effectiveDate: string | null;
    termDate: string | null;
    createdBy: string;
    createdDate: string | null;
    updatedBy: string;
    updatedDate: string | null;
    providerid: number | null;
}
export class ProviderStatusGrid {
    statusId: number;
    providerStatusId: number | null;
    lobId: string;
    groupId: number | null;
    address: string;
    effectiveDate: string | null;
    termDate: string | null;
    providerid: number | null;
}