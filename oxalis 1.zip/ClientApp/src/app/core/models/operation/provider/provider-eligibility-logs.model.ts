export class ProviderEligibilityLogsModel {
    providerEligibilityLogId: number;
    providerID: number;
    updatedBy?: string;
    updatedField: string;
    oldValue?: string | Date;
    updatedValue: string | Date;
    updatedDate: string;
    action: string;
}