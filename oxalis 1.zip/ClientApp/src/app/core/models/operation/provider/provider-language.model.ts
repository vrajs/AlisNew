import { BaseModel } from "@app/core/models"

export class ProviderLanguage extends BaseModel {
    providerLanguageId: number;
    providerId: number;
    languageId: number;
    language: string;
 
    constructor() {
        super();
    }
 }
 