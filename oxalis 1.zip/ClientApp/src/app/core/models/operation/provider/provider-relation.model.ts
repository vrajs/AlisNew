import { BaseModel } from "../../common/base.model";
import { ProviderViewModel } from "./provider.model";

export class ProviderRelationModel extends BaseModel {
    providerRelationId: number;
    parentProviderId: number;
    relatedProviderId: number;
    relationTypeId: number;
    effectiveDate: Date;
    termDate: Date;
    isPrimaryPCP?: boolean | null | undefined;
    provider?: ProviderViewModel | null | undefined;
    constructor() {
        super();
    }
}
