import { BaseModel, ProviderEligibility, ProviderLanguage } from "@app/core/models"
import { ProviderType } from '../../../../common/app-enum';

export class ProviderModel extends BaseModel {
    providerId: number;
    providerTypeId: number;
    providerTypeName?: string;
    providerCode: string;
    title: string;
    lastName: string;
    firstName: string;
    middleName: string;
    suffix: string;
    fullName: string;
    dob?: Date;
    gender: string;
    ssn: string;
    npi: string;
    tin: string;
    phone: string;
    fax: string;
    primaryEmail: string;
    secondaryEmail: string;
    credentialStatusId: number;
    groupId: string;
    isPcp: boolean;
    isGroup: boolean;
    isSpecialist: boolean;
    isProviderWatch: boolean;
    isPerson: boolean;
    isProviderAccess?: boolean;
    isAcceptsMedicaid: boolean;
    race: string;
    ethnicity: string;
    maxMemberCount: number;
    providerEligibilityId?: number;
    languages?: string;
    providerLanguage: Array<ProviderLanguage> = [];
    providerLanguageIds: string[];
    prefix?: string;
    providerEligibility: ProviderEligibility[];
    effectiveDate: Date;
    termDate?: Date;

    constructor() {
        super();
        this.providerTypeId = ProviderType.Provider;
        this.title = '';
        this.firstName = '';
        this.middleName = '';
        this.lastName = '';
        this.suffix = '';
        this.gender = '';
        this.ssn = '';
        this.npi = '';
        this.tin = '';
        this.phone = '';
        this.fax = '';
        this.primaryEmail = '';
        this.secondaryEmail = '';
        this.race = '';
        this.ethnicity = '';
        this.providerLanguage = [];
        this.providerLanguageIds = ['5841'], //static for auto select ENGLISG language from commoncode
            this.isPerson = true,
            this.isPcp = false,
            this.prefix = '',
            this.providerEligibility = [];
        this.maxMemberCount = 0;
    }
}

export class ProviderViewModel {
    providerId: number;
    providerTypeID: number;
    providerCode: string;
    title: string;
    lastName: string;
    firstName: string;
    middleName: string;
    suffix: string;
    fullName: string;
    dob?: Date;
    gender: string;
    ssn: string;
    npi: string;
    tin: string;
    phone: string;
    fax: string;
    primaryEmail: string;
    secondaryEmail: string;
    credentialStatusID: number;
    isPCP: boolean;
    isSpecialist: boolean;
    isProviderWatch: boolean;
    isPerson: boolean;
    isProviderAccess?: boolean;
    race: string;
    ethnicity: string;
    maxMemberCount: number;
    providerEligibilityID?: number;
    serviceRenderedID: number;
    effectiveDate?: Date;
    termDate?: Date;
    prefix?: string;
    constructor() {
        this.providerId = 0;
    }
}

export class HasProviderConfigurationData {
    hasEligigbilityData: boolean = false;
    hasSpecialtyData: boolean = false;
    hasReferenceData: boolean = false;
    hasNotesData: boolean = false;
    hasProviderLocationData: boolean = false;
    hasProviderContractData: boolean = false;
}

export class HasGroupConfigurationData {
    hasEligigbilityData: boolean = false;
    hasSpecialtyData: boolean = false;
    hasIPAData: boolean = false;
    hasProviderRelationData: boolean = false;
    hasLocationData: boolean = false;
    hasProviderLocationData: boolean = false;
    hasContractData: boolean = false;
    hasProviderContractData: boolean = false;
    hasReferenceData: boolean = false;
    hasNotesData: boolean = false;
    hasEftData: boolean = false;
    hasTinData: boolean = false;
    hasCheckHistoryData: boolean = false;
}


