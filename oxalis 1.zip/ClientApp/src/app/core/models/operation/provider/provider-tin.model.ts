export class ProviderTINModel {
    providerTINId: number;
    providerId: number;
    tinTypeId: number;
    tinType: string;
    tinNumber: number;
    tinName: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}
