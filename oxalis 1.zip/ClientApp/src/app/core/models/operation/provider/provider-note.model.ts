import { BaseModel } from "../../common/base.model";

export class ProviderNoteModel extends BaseModel {    
    providerNoteId: number;    
    providerId: number;    
    shortDescription: string;    
    longDescription: string;    
    noteDate: Date;    
    effectiveDate: Date;    
    termDate: Date;        
}