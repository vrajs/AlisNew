export class RefundStatusModel {
    refundStatusId: number;
    refundStatusCode: string;
    refundStatusDescription: string;
    refundStatusCategory: string;
    constructor() {

    }

}
