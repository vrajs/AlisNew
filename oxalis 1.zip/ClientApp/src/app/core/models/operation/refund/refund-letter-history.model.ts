export class RefundLetterHistory {
    refundLetterID: number;
    refundRequestID: number;
    letterDate: Date;
    letterTypeID: number;
    documentNo: string;
    letterHTMLContent: string;
    constructor() {

    }
}
