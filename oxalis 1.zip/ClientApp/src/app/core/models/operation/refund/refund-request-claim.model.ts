import { RecordStatus } from "@app/common/app-enum";
import { ClaimLoockupModel } from "../claim";

export class RefundRequestClaimModel {
    public refundRequestClaimId: number;
    public refundRequestId: number;
    public claimHeaderId: number;
    public memberId: number;
    public claimNumber: string;
    public requestedAmount: number;
    public billedAmount: number;
    public paidAmount: number;
    public recordStatus: number;
    public isFreezed: number;
    public recordStatusChangeComment: string;
    public createdBy: string;
    public createdDate: Date;
    public updatedBy: string;
    public updatedDate?: Date;
    public addedSource: string;
    public updatedSource: string;
    public loadComment: string;
    public claimInfo: ClaimLoockupModel;
    public requestedAmountIgNumericOptions: any;
    public vendorName: string;
    public providerGroupTin: string;
    constructor() {
        this.refundRequestId = 0;
        this.requestedAmount = 0;
        this.refundRequestClaimId = 0;
        this.claimHeaderId = 0;
        this.recordStatus = RecordStatus.Active;
        this.recordStatusChangeComment = '';
        this.claimNumber = '';
        this.createdBy = '';
        this.updatedBy = '';
        this.addedSource = '';
        this.updatedSource = '';
        this.loadComment = '';
    }
}
