export class RefundPostingModel {
    refundPostingId: number;
    refundRequestId: number;
    refundReceivedId: number;
    entryTypeId: number;
    claimHeaderId: number;
    memberId: number;
    memberName: Text;
    claimNumber: string;
    postedAmount: number;
    postedDate: Date;
    recoupmentAmount: number;
    isPosted: number;
    balanceAmount: number;
    comment: Text;
    entryType: Text;
    checkNo: Text;
    constructor() {
        this.refundPostingId = 0;
        this.refundReceivedId = 0;
    }
}
