// Project Namespace

import { RefundStatus, StringFilterType } from "@app/common/app-enum";

export class RefundSearchModel {
    status: number;
    chequeNumber: number;
    memberId: string;
    memberIdFilterId: number;
    providerId: string;
    providerIdFilterId: number;
    claimId: string;
    constructor() {
        this.status = RefundStatus.All;
        this.memberIdFilterId = StringFilterType.Contain;
        this.providerIdFilterId = StringFilterType.Contain;
        this.status = -1;
        this.chequeNumber = -1;
    }
}
