import { parseDate } from "@infragistics/igniteui-angular/lib/core/utils";
import { GridFilter } from "../../common/grid-filter.model";

export class TRRFalloutsSearchModel  extends GridFilter {
    
    constructor() {
        super();
        this.trrDetailLayoutID = 0;
        this.MBI = "";
        this.transactionDate = "";
        this.fileName = "";
        this.transactionReplyCode = "";
        this.trc = "";
        this.memberId = "";
        this.falloutReason = "";
        this.falloutStatus = "";
        this.planID  = "";
        this.orderByColumn = "MBI";
        this.isDesc = true;
    }
    trrDetailLayoutID : number;
    MBI: string;
    transactionDate: any;
    fileName: any;
    transactionReplyCode: any;
    trc: any;
    memberId : any;
    falloutReason : any;
    falloutStatus: any;
    planID : any;
    orderByColumn: string;
    isDesc: boolean;
}


export class TRRFalloutsUpdateModel  {
    
    constructor() {
        this.trrDetailLayoutId = 0;
        this.falloutStatus = 0;
    }
    trrDetailLayoutId : number;
    falloutStatus: number;
}
