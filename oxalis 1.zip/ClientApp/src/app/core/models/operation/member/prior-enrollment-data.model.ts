export class PriorEnrollmentDataModel{
    priorCoverageName: string;
    ehgp: number;
    creditableCoverage: number;
    numberOfUncoveredMonths:number;
    lepRequestedDate: Date;
    lepResponseDate: Date;
    lepStartDate: Date;
    lepEndDate: Date;
}