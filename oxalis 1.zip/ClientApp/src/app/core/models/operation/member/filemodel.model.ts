export class Filemodel {
    constructor() {
        this.fileData = "";
        this.fileName = "";
    }
    fileData: any;
    fileName: any;
}
