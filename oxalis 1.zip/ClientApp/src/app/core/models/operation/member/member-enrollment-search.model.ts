import { parseDate } from "@infragistics/igniteui-angular/lib/core/utils";
import { GridFilter } from "../../common/grid-filter.model";

export class MemberEnrollmentSearchModel extends GridFilter {
    constructor() {
        super();
        this.trackingId = null;
        this.mbi = null;
        this.firstName = null;
        this.lastName = null;
        this.memberId = null;
        this.applicationStatusId = null;
        this.pbpId = null;
        this.memberStatusID = null;
        this.contractId = null;
        this.transactionTypeId = null;
        this.effectiveDate = null;
        this.clientMemberId = null;
    }
    trackingId: string;
    mbi: string;
    firstName: string;
    lastName: string;
    memberId: string;
    applicationStatusId: number;
    pbpId: number;
    memberStatusID: number;
    contractId: number;
    transactionTypeId: number;
    effectiveDate: Date;
    clientMemberId: string;
}
export class CheckMemberModel {
    firstName: string;
    lastName: string;
    gender: number;
    dob: Date;
}