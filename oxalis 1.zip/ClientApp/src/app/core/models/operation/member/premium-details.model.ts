export class PremiumDetailsModel {
    lowIncomeCopayId: number;
    lowIncomeCopay: number;
    partDLEPAmount: number;
    partCPremiumAmount: number;
    partDLEPWaivedAmount: number;
    partDPremiumAmount: number;
    partDLEPSubsidyAmount: number;
    permanentAddressCounty: string;
    lowIncomePartDPremiumSubsidyAmount: string;
}