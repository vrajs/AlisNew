export class MemberEnrollmentReportModel {
    memberId: number | null;
    name: string;
    enrollmentSourceId: string;
    pBPID: string;
    sNP: string;
    contractID: number | null;
    memberStatusId: string;
    transactionStatusId: string;
    salesAgentId: number | null;
    state: string;
    county: string;
    effectiveDateFrom: string | null;
    effectiveDateTo: string | null;
    processedDateFrom: string | null;
    processedDateTo: string | null;
    skip: number;
    take: number;
}