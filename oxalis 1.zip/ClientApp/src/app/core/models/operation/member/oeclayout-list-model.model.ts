export class OECLayoutListModel {
    oecLayoutId: number;
    dataFileToProcessDetailsId: number;
    confirmationNumber: string;
    applicantFirstName: string;
    applicantLastName: string;
    loadComment: string;
}
