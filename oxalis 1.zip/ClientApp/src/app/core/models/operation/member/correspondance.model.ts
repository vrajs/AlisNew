import { PlaceHolderReplaceViewModel } from "./placeHolder.model";

export class LetterCorrespondance {
    letterCorrespondanceId: number;
    letterTypeId: number | null;
    letterType: string | null;
    memberId: number | null;
    letterGenerationDate: string | null;
    letterMailDate: string | null;
    responseDueDate: string | null;
    updatedDate: string | null;
    updatedBy: string;
    createdDate: string | null;
    createdBy: string;
    source: string;
    comments: string;
    mbi: string | null;
    placeHolderReplaceViewModel: PlaceHolderReplaceViewModel;
}