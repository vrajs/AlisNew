export class AuditHistory {
    auditHistoryId: number;
    memberId: number | null;
    modifiedField: string;
    beforeValue: string;
    afterValue: string;
    modifiedDate: string | null;
    modifiedBy: string;
    source: string;
    mBI: string;
}
export class ProviderAuditHistory {
    providerAuditHistoryId: number;
    providerId: number | null;
    modifiedField: string;
    beforeValue: string;
    afterValue: string;
    modifiedDate: string | null;
    modifiedBy: string;
}