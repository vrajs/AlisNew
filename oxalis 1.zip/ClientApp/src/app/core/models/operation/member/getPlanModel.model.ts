export class GetPlanModel {
    public healthPlanID: number;
    public planCode: string;
    public planName: string;
    public lob: string;
    public pbpCode: string;
    public productType: string;
    public state: string;
    public county: string;
    public company: string;
    public subCompany: string;
    public effectiveDate: Date;
    public termDate: Date;
    public approvalDate: Date;
    public approvalStatus: string;
    public recordStatus: number;
    public lobID: number;
}
