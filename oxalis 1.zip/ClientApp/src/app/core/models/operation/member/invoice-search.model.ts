export class InvoiceSearchModel {
    mBI: string;
    memberID: number;
    invoiceNumber: string;
    lastName: string;
    firstName: string;
    invoiceMonthFrom: string | null;
    invoiceMonthTo: string | null;
    pBPID: number | null;
    invoiceType: string;
    skip: number;
    take: number;
}