export class MemberPayment {
    memberPaymentId: number;
    mBI: string;
    memberId: number;
    firstName: string;
    lastName: string;
    totalDueAmount: number;
    paymentMonth: string;
    invoiceNumber: string;
    paidVia: string;
    paidDate: string;
    paidAmount: number;
    chequeNumber: string;
    accountNumber: string;
    creditCardNo: string;
    onlinePaymentReference: string;
    enrolledPlan: string;
    paymentId: string;
    planAmount: number;
    invoiceBalance: number;
}
export class MemberPaymentSearchModel {
    mbi: string;
    memberID: number | null;
    lastName: string;
    paidVia: string;
    firstName: string;
    pbpId: number | null;
    fromDate: string | null;
    toDate: string | null;
    skip: number;
    take: number;
}

export class PaymentListModel {
    memberPaymentList: MemberPaymentList[];
    totalCount: number;
}

export class MemberPaymentList {
    memberPaymentId: number;
    mBI: string;
    memberID: number | null;
    lastName: string;
    firstName: string;
    planId: string;
    paidDate: string;
    paidVia: string;
    paidAmount: number;
}