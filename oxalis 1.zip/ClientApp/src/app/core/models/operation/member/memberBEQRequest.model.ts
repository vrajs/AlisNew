export class MemberBEQRequestModel {
    beneficiaryIdentifier: string;
    beneficiaryBirthDate: string;
    beneficiaryGender: string;
    userId:string;
}