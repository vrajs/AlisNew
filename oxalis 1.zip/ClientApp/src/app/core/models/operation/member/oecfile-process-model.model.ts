export class OECFileProcessModel {
    dataFileToProcessDetailsId: number;
    generatedFileName: string;
    runId: string;
    runStatus: string;
    errorMessage: string;
}
