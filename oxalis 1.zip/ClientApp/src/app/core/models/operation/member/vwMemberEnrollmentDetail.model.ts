export class vwMemberEnrollmentDetail {
    memberEnrollmentHeaderID: number;
    memberID: number;
    trackingID: string | null;
    mBI: string;
    firstName: string;
    lastName: string;
    middleName: string;
    clientMemberId: string;
    contractID: number;
    applicationStatusID: number | null;
    pBPID: number | null;
    pbpDescription: string | null;
    contractDescription: string;
    memberStatus: string;
    createdDate: string;
    createdBy: string;
    recordStatus: number;
    applicationStatusName: string;
}