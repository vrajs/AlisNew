export class PlanEligibilitySpan {
    planEligibilitySpanId: number;
    planId: string;
    effectiveDate: string | null;
    termDate: string | null;
    pCP: string;
    memberId: number;
    updatedDate: string | null;
    updatedBy: string;
    createdDate: string | null;
    createdBy: string;
}