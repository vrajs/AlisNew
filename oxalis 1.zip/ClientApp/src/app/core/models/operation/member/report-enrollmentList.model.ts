export class ReportEnrollmentListModel {
    memberId: number | null;
    memberName: string;
    pBPID: string;
    contractID: string;
    incompleteReason: string;
    effectiveDate: string | null;
    rFIRequestedDate: string | null;
    rFIDueDate: string | null;
    age: number | null;
}