export class TransactionStatusWiseFilter {
    pBPID: string;
    contractID: number | null;
    transactionTypeId: string;
    transactionStatusID: string;
    effectiveDateFrom: string | null;
    effectiveDateTo: string | null;
}