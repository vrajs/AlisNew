import { CMSReportModel } from "./cms-report.model";
import { DenialReportListModel } from "./denial-report.model";
import { MemberEnrollmentList } from "./member-enrollment-list.model";
import { ReportEnrollmentListModel } from "./report-enrollmentList.model";

export class MemberEnrollmentListViewModel {
    memberEnrollmentList: MemberEnrollmentList[];
    totalCount: number;
}
export class ReportEnrollmentListViewModel {
    memberEnrollmentList: ReportEnrollmentListModel[];
    totalCount: number;
}
export class DenialReportListViewModel {
    memberEnrollmentList: DenialReportListModel[];
    totalCount: number;
}
export class CMSReportListViewModel {
    cmsEnrollmentList: CMSReportModel[];
    totalCount: number;
}