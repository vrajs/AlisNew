export class IssueDashboardViewModel {
    id: number;
    title: string;
    issueCount: number;
    dueDate: string;
    activityTypeCounts: { [key: string]: number; };
}
export class DueActivity {
    [x: string]: any;
    dueActivityId: number;
    memberId: number;
    transactionDetailId: number | null;
    contract: string;
    pBP: string;
    transactionType: string;
    receiptDate: string | null;
    dueDate: string;
    actualDate: string | null;
    activityType: string;
    flag: string;
    createdDate: string | null;
    updatedDate: string | null;
}