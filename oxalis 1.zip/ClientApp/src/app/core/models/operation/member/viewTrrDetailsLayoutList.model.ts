export class VwTRRDetailLayoutListModel {
    trrDetailLayoutId: number;
    transactionReplyCode: string;
    transactionReplyCodeName: string;
    transactionCode: string;
    transactionCodeName: string;
    effectiveDate: string;
    transactionDate: string;
    memberTransactionDetailId: number | null;
    pbpid: number;
    pbpName: string;
    contractId: number; 
    contractName: string;
    transStatus: string;
    memberId: number | null;
}