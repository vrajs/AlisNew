import { SaveMemberPreEnrollment } from "../..";
import { BaseModel } from "../../common/base.model";

export class MemberPreEnrollmentAttachment extends BaseModel {
    memberPreEnrollmentAttachmentId: number;
    memberPreEnrollmentId: number | null;
    fileName: string;
    fileLocation: string;
    // effectiveDate: string | null;
    // termDate: string | null;
    memberPreEnrollment: SaveMemberPreEnrollment;
}