export class FileTemplateList {
    fileSubCategoryId: number;
    fileCategoryId: number;
    dataFileToProcessDetailsID: number;
    fileName: string;
    fileType: string;
    fileDate: Date;
    createdBy: string;
    records: number;
}

// export class FileTemplateList {
//     fileTemplateTypeId: number;
//     dataFileTemplateId: number;
//     dataFileToProcessDetailsID: number;
//     fileName: string;
//     fileType: string;
//     fileDate: Date;
//     createdBy: string;
//     records: number;
// }