// Project Namespace

import { StringFilterType } from "@app/common/app-enum";


export class ClaimLoockupSearchModel {
    claimNumber: string;
    claimNumberFilterId: number;
    providerName: string;
    providerNameFilterId: number;
    providerCode: string;
    providerCodeFilterId: number;
    memberName: string;
    memberNameFilterId: number;
    memberCode: string;
    memberCodeFilterId: number;
    claimTypeId: number;
    claimStatusId: number;
    checkNumber: number;
    checkNumberFilterId: number;
    authorizationNumber: string;
    authorizationNumberFilterId: number;
    dosFrom: Date;
    dosTo: Date;
    paidFrom: Date;
    paidTo: Date;
    receivedFrom: Date;
    receivedTo: Date;
    constructor() {
        this.claimNumberFilterId = StringFilterType.Contain;
        this.providerNameFilterId = StringFilterType.Contain;
        this.memberNameFilterId = StringFilterType.Contain;
        this.providerNameFilterId = StringFilterType.Contain;
        this.authorizationNumberFilterId = StringFilterType.Contain;
        this.memberCodeFilterId = StringFilterType.Contain;
        this.providerCodeFilterId = StringFilterType.Contain;
        this.checkNumberFilterId = StringFilterType.Contain;
        this.claimTypeId = -1;
        this.claimStatusId = -1;
    }
}
