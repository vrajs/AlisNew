export class ClaimListingModel {
    claimId: number;
    fileId: number;
    tradingPartnerId: string;
    uploadedDate: string;
    memberId: string;
    name: string;
    dob: string;
    renderingProvider?: string;
    billingProvider: string;
    billingProviderNpi?: string;
    billtype: string;
    patientControlNumber: string;
    claimNo?: string;
    billed: number;
    claimStatus: number | string;
    claimErrorCount: number;
    claimErrorMsg?: string;
    hasError: string;
    
}