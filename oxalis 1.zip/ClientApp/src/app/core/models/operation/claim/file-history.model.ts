export class FileHistoryModel {
    fileID: number;
    fileName: string;
    createdBy: string;
    description: boolean;
    status: string;    
    createdDate: Date;
}