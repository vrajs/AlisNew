﻿export class ClaimOtherPhysicianModel 
 {

    public claimOtherPhysicianId: number ;
    public claimHeaderId: number ;
    public physicianTypeId: number ;
    public physicianCode: string ;
    public qualifierId: number ;
    public lastName: string ;
    public firstName: string ; 

}