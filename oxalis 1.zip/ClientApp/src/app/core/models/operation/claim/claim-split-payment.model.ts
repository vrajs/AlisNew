﻿import { BaseModel } from '../../common/base.model';

export class ClaimSplitPaymentModel extends BaseModel {
    claimSplitPaymentID: number;
    claimHeaderID: number;
    memberReimbursement: number;
    reimburseReminderToProvider: boolean;
    reasonForSplitPayment: string;
}