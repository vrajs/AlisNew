import { ClaimEditsModel } from "@app/core/models/operation/claim";

export class AdjudicationResultModel {
    public claimHeaderId: number;
    public claimStatusId: number;
    public claimStatus: string;
    public previousClaimStatusId: number;
    public previousClaimStatus: string;
    public claimStatusCategory: string;
    public claimEdits: ClaimEditsModel[];
}
