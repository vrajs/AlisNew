﻿import { BaseModel } from '../../common/base.model';

export class ClaimPaymentModel extends BaseModel {
    claimPaymentID: number;
    claimHeaderID: number;
    lastUpdated: Date;
    userInitials: string;
    paidDate: Date;
    checkDate?: Date;
    checkNumber: number;
    checkAmount: number;
    checkClearedDate?: Date;
}
