

export class ClaimDiagnosisModel {
    claimDiagnosisId: number;
    claimHeaderId: number;
    memberId: number;
    diagnosisTypeId: number;
    diagnosisCode: string;
    diagnosisDescription: string;
    qualifier: string;
    diagnosisPointer: number;
    isPoa: boolean;
    procDate: Date;
    dosFrom: Date;
    dosTo: Date;
    addedSource: string;
    constructor() {
        this.diagnosisTypeId = 0;
        this.addedSource = '';
    }
}
