﻿import { BaseModel } from '../../common/base.model';

export class ClaimProcessingStepsModel extends BaseModel {
    claimProcessingStepsId: number;
    claimHeaderId: number;
    claimDetailLine: number;
    processDate:Date;
    processStep: string;
    processValue: string;
}