import { BaseModel } from "@app/core/models";

export class AccountDetailModel extends BaseModel {

    public accountDetailID: number;
    public accountTypeID: number;
    public accountNumber: string;
    public routingNumber: string;
    public bankName: string;
    public is835: boolean;
    public isEFT: boolean
    public effectiveDate: Date;
    public termDate: Date | null | undefined;
    public type: string;

    constructor() {
        super();
        this.accountDetailID = 0;
    }
}
