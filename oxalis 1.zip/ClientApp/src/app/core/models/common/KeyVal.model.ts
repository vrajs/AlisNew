export class KeyValModel {
    key: any;
    value: any;
}

export class DropdownModel extends KeyValModel{
    description: string;
}