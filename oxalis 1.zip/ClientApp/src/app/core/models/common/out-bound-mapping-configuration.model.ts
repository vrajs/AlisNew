export class OutboundMappingconfigurationModel {
    outboundMappingconfigurationId: number;
    elementId: number;
    dataFileConfigurationId: number;
    sourceField: string;
    destinationField: string;
    createdBy: string;
    createdDate: Date;
    recordStatus: number;
    updatedDate: Date;
    updatedBy: string;
}
