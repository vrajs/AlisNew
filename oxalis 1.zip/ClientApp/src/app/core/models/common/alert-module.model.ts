export class AlertModuleViewModel {
   public alertModuleId: number;
   public sourceModuleId: number;
   public sourceModuleName: string;
   public destinationModuleId: number;
   public destinationModuleName: string;
   public alertDataId: number;
   public alertCodeId: number;
   public alertCodeValue: string;
   public alertCodeName: string;
   public effectiveDate: Date;
   public termDate: Date;
   public url: string;
   constructor() {

   }
}


export class AlertCodeModel {
   public alertCodeId: number;
   public code: string;
   public name: string;
   public url: string;
}

