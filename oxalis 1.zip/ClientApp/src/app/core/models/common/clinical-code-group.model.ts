import { BaseModel } from "@app/core/models";

export class ClinicalCodeGroupModel extends BaseModel {
    clinicalCodeGroupId: number;
    groupCode: string;
    groupName: string;
}

export class ClinicalCodeSubGroupModel extends BaseModel {
    clinicalCodeSubGroupId: number;
    clinicalCodeGroupId: number;
    subGroupCode: string;
    subGroupName: string;
}

export class ClinicalCodeGroupDetail extends BaseModel {
    clinicalCodeGroupDetailId: number;
    groupTypeId: number = 0;
    clinicalCodeSubGroupId: number = -1;
    clinicalCodeSubGroup: string;
    subCategoryName: string;
    clinicalCodeTypeId: number;
    startCode: string;
    endCode: string;
    excludeStartCode: string;
    excludeEndCode: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
    isAuth: boolean = false;
    //constructor() {
    //    this.clinicalCodeSubGroupID = -1;
    //}
}


