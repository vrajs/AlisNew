export class CommonCodeDisplayConfigurationModel {
    public commonCodeId: number;
    public pageId: string|any;
    public commonCodeIdList: number[];

    constructor() {
        this.commonCodeId = 0;
        this.pageId = null;
        this.commonCodeIdList = [];
    }
}
