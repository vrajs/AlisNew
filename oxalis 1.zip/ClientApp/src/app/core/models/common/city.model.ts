export class CityModel{
    city: string | null;
    recordStatus: string | null;
}