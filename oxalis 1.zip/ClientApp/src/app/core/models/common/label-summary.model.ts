import { IgxSummaryResult } from "igniteui-angular";

export class LabelSummary {

    public operate(data?: any[]): IgxSummaryResult[] {
        const result = [];
        result.push({
            key: 'Total',
            label: '',
            summaryResult: "",
        });
        return result;
    }
}