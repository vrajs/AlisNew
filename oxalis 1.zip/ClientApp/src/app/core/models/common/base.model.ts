import { RecordStatus} from '@app/common/app-global';

export class BaseModel {

    recordStatus: number;
    isFreezed: number;
    recordStatusChangeComment: string;

    createdBy: string;
    createdDate: Date;

    updatedBy?: string;
    updatedDate?: Date | null | undefined;

    constructor() {
        this.createdBy = '';
        this.recordStatus = RecordStatus.Active;
        this.recordStatusChangeComment = 'Active';
    }
}
