export class CommonCodeConfigurationModel {
    commonCodeId: number;
    pageId: string;
    charValue: string;
    code: string;
    shortName: string;
    longDescription: string;
    numericValue: number;
    displayOrder: number;
    codeTypeId: number;
    effectiveDate: string;
    termDate: string;
    recordStatus: number;
    controlTypeId: number;
}