//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-functions';
import { BenefitCopayPerDiemModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class BenefitCopayDiemService {

  constructor(private httpClient: HttpClient) { }

  /**
  * Purpose: Method is use to get benefit copay per diem
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay per diem
  */
  get(): Observable<BenefitCopayPerDiemModel[]> {
    return this.httpClient.get<BenefitCopayPerDiemModel[]>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel[];
      })
    );
  }


  /**
  * Purpose: Method is use to get benefit copay per diem by id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay per diem by id
  */
  getById(BenefitCopayPerDiemId: number): Observable<BenefitCopayPerDiemModel> {
    return this.httpClient.get<BenefitCopayPerDiemModel>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem/${BenefitCopayPerDiemId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel;
      })
    );
  }


  /**
  * Purpose: Method is use to get benefit copay per diem by benefit header id
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - get benefit copay per diem by benefit header id
  */
  getBenefitCopayDiemByBenefitHeaderId(BenefitHeaderId: number): Observable<BenefitCopayPerDiemModel[]> {
    return this.httpClient.get<BenefitCopayPerDiemModel[]>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem/GetBenefitCopayPerDiemHeaderId/${BenefitHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel[];
      })
    );
  }

  /**
  * Purpose: Method is use to create benefit copay per diem 
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - create benefit copay per diem 
  */
  create(model: BenefitCopayPerDiemModel): Observable<BenefitCopayPerDiemModel> {
    return this.httpClient.post<BenefitCopayPerDiemModel>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update benefit copay per diem 
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - update benefit copay per diem 
  */
  update(model: BenefitCopayPerDiemModel): Observable<BenefitCopayPerDiemModel> {
    return this.httpClient.put<BenefitCopayPerDiemModel>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete benefit copay per diem 
  * @author Gaurav Vaghela #O9-53 on 23-May-2022 - delete benefit copay per diem 
  */
  delete(benefitCopayPerDiemId: number): Observable<BenefitCopayPerDiemModel> {
    return this.httpClient.delete<BenefitCopayPerDiemModel>(`${environment.serviceApiUrl}/api/BenefitCopayPerDiem/${benefitCopayPerDiemId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BenefitCopayPerDiemModel;
      })
    );
  }

}
