import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { DeductibleOopModel, HealthPlanDeductibleModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { Observable, map } from "rxjs";

@Injectable()
export class DeductibleService {
    constructor(private httpClient: HttpClient) { }

    /**
   * Purpose: Method is use get Health Plan DeductibleList
   * @author Dupendra Pawar # on 06-May-2022 - Get method
  */
    getHealthPlanDeductibleList(page: string, healthPlanId: number): Observable<HealthPlanDeductibleModel[]> {
        return this.httpClient.get<HealthPlanDeductibleModel[]>(`${environment.serviceApiUrl}/api/HealthPlanDeductible/${page}/${healthPlanId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as HealthPlanDeductibleModel[];
            })
        );
    }

    /**
     * Purpose: Method is use get Health Plan Deductible by Id
     * @author Dupendra Pawar # on 06-May-2022 - Get method
    */
    getHealthPlanDeductibleById(deductibleId: number): Observable<DeductibleOopModel> {
        return this.httpClient.get<DeductibleOopModel>(`${environment.serviceApiUrl}/api/HealthPlanDeductible/${deductibleId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as DeductibleOopModel;
            })
        );
    }

    /**
     * Purpose: Method is use to save deductible
     * @author Dupendra Pawar # on 06-May-2022 - Post method
    */
    saveDeductible(deductibleOopModel: DeductibleOopModel): Observable<DeductibleOopModel> {
        return this.httpClient.post<DeductibleOopModel>(`${environment.serviceApiUrl}/api/HealthPlanDeductible`, deductibleOopModel).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as DeductibleOopModel;
            })
        );
    }

    /**
     * Purpose: Method is used to update deductible
     * @author Dupendra Pawar # on 06-May-2022 - Put method
    */
    updateDeductible(deductibleOopModel: DeductibleOopModel): Observable<DeductibleOopModel> {
        return this.httpClient.put<DeductibleOopModel>(`${environment.serviceApiUrl}/api/HealthPlanDeductible`, deductibleOopModel).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as DeductibleOopModel;
            })
        );
    }

    /**
     * Purpose: Method is used to delete deductible
     * @author Dupendra Pawar # on 06-May-2022 - Delete method
    */
     deleteDeductibleById(deductibleId: number): Observable<DeductibleOopModel> {
        return this.httpClient.delete<DeductibleOopModel>(`${environment.serviceApiUrl}/api/HealthPlanDeductible/${deductibleId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as DeductibleOopModel;
            })
        );
    }


}