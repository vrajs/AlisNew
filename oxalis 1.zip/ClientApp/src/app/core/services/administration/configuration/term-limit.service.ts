//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { environment } from '@environments/environment';
import { TermLimitModel } from '@app/core/models/administration/configuration/term-limit.model';
//#endregion

@Injectable()

export class TermLimitService {

  constructor(private httpClient: HttpClient) { }

  /**
 * Purpose: Method is use to get Term Limit
 * @author Shivam Modi on 13-June-2022 - get Term Limit
 */
  get(): Observable<TermLimitModel[]> {
    return this.httpClient.get<TermLimitModel[]>(`${environment.serviceApiUrl}/api/TermLimit`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel[]
      })
    );
  }

  //  /**
  // * Purpose: Method is use to get Term Limit for view
  // * @author Shivam Modi on 13-June-2022 - get Term Limit for view
  // */
  // getByIdForView(TermLimitId: number): Observable<TermLimitModel> {
  //   return this.httpClient.get<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit/GetByIdForView/${TermLimitId}`).pipe(
  //     map(res => {
  //       res = Utils.camelizeKeys(res);
  //       return res as TermLimitModel
  //     })
  //   );     
  // }

  /**
 * Purpose: Method is use to get Term Limit by id
 * @author Shivam Modi on 13-June-2022 - get Term Limit by id
 */
  getById(TermLimitId: number): Observable<TermLimitModel> {
    return this.httpClient.get<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit/${TermLimitId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel
      })
    );
  }

  /**
  * Purpose: Method is use to create Term Limit
  * @author Shivam Modi on 13-June-2022 - create Term Limit 
  */
  create(model: TermLimitModel): Observable<TermLimitModel> {
    return this.httpClient.post<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update Term Limit
  * @author Shivam Modi on 13-June-2022 - update Term Limit 
  */
  update(model: TermLimitModel): Observable<TermLimitModel> {
    return this.httpClient.put<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete Term Limit
  * @author Shivam Modi on 13-June-2022 - delete Term Limit 
  */
  delete(TermLimitId: number): Observable<TermLimitModel> {
    return this.httpClient.delete<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit/${TermLimitId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel;
      })
    );
  }

  getTermLimitByTermHeaderID(TermHeaderId: number): Observable<TermLimitModel> {
    return this.httpClient.get<TermLimitModel>(`${environment.serviceApiUrl}/api/TermLimit/GetTermLimitByTermHeaderID/${TermHeaderId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermLimitModel;
      })
    );
  }
}
