//#region System Namespace
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

//#endregion

//#region Model Namespace
import { RuleHeaderEditRuleCategoryViewModel, RuleHeaderEditRuleModel } from '@app/core/models';
import { HttpClient } from '@angular/common/http';
import { Utils } from '@app/common/app-functions';
import { environment } from '@environments/environment';
//#endregion


@Injectable()
export class RuleHeaderEditRuleService {

    //#region Property
    private apiBaseUrl: string = '/api/RuleHeaderEditRule';
    //#endregion

    //#region Constructor
    constructor(private httpClient: HttpClient) { }
    //#endregion

    //#region Get Methods
    public getCategory(ruleHeaderID: number): Observable<Array<RuleHeaderEditRuleCategoryViewModel>> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetCategory/${ruleHeaderID}`).pipe(
            map((response) => {
                response = Utils.camelizeKeys(response);
                return response as RuleHeaderEditRuleCategoryViewModel[];
            })
        );
    }

    public getEdits(ruleHeaderID: number, category: string): Observable<Array<RuleHeaderEditRuleModel>> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetEdits/${ruleHeaderID}/${category}`).pipe(
            map((response) => {
                response = Utils.camelizeKeys(response);
                return response as RuleHeaderEditRuleModel[];
            })
        );
    }

    public getByID(ruleHeaderID: number, editCodeID: number): Observable<RuleHeaderEditRuleModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetByID/${ruleHeaderID}/${editCodeID}`).pipe(
            map(response => {
                response = Utils.camelizeKeys(response);
                return response as RuleHeaderEditRuleModel;
            })
        );
    }
    //#endregion

    //#region Post & Put & Delete Methods
    create(model: RuleHeaderEditRuleModel): Observable<number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model).pipe(
            map((response) => {
                return response as number;
            })
        );
    }

    update(model: RuleHeaderEditRuleModel): Observable<number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, model).pipe(
            map((response) => {
                return response as number;
            })
        );
    }

    public delete(ruleHeaderEditRuleID: number): Observable<number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderEditRuleID}`).pipe(
            map((response) => {
                return response as number;
            })
        );
    }
    //#endregion

    //#region Enable Or Disable Edit
    public enableDiableEdit(ruleHeaderEditRuleID: number, isEnabled: boolean): Observable<number> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/EnableDiableEdit/${ruleHeaderEditRuleID}/${isEnabled}`).pipe(
            map((response) => {
                return response as number;
            })
        );
    }
    //#endregion
}