import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, Subject } from 'rxjs';
import { Utils } from '@app/common/app-functions';
import { FileTemplateModel } from '@app/core/models/administration/configuration/file-template.model';
import { FileTemplateListView } from '@app/core/models/operation/member/file-template-list-view.model';
import { FileTemplateSearch } from '@app/core/models/operation/member/file-template-search.model';
import { environment } from '@environments/environment';
import { FileSubCategoryModel } from '@app/core/models';
import { TrcConfigData, TrcConfigSearch } from '@app/core/models/operation/member/trc-config.model';

@Injectable({
  providedIn: 'root'
})
export class FileTemplateService {
  searchMember$: Observable<any>;
  searchMemberSubject = new Subject<any>();
  constructor(private httpClient: HttpClient) {
    this.searchMember$ = this.searchMemberSubject.asObservable();
  }

  searchMember(data) {
    this.searchMemberSubject.next(data);
  }

  GetFileTemplateTypes(): Observable<FileTemplateModel[]> {
    return this.httpClient.get<FileTemplateModel[]>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileTemplateTypes`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileTemplateModel[];
      })
    );
  }

  GetFileTemplateDetails(searchModel: FileTemplateSearch, fileType: string): Observable<FileTemplateListView> {
    let searchModelString = JSON.stringify(searchModel);
    return this.httpClient.get<FileTemplateListView>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileTemplateDetails?searchModelString=${searchModelString}&filetype=${fileType}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileTemplateListView;
      })
    );
  }
  SetPlanActions(planActionIds: number[], trcCode: string, contractId: number, pbpId: number[]): Observable<any> {
    let params = new HttpParams();
    params = params.append('contractId', contractId.toString());
    pbpId.forEach(id => {
      params = params.append('pbpId', id.toString());
    });

    return this.httpClient.post<any>(
      `${environment.serviceApiUrl}/api/CommonCode/SetPlanActions/${trcCode}`,
      planActionIds,
      { params });
  }
  GetAllPlanActions(searchModelString: TrcConfigSearch): Observable<any> {
    searchModelString.contractId = searchModelString.contractId == null ? 0 : searchModelString.contractId;
    searchModelString.pbpId = searchModelString.pbpId == null ? new Array[0] : searchModelString.pbpId;
    let searchModel = JSON.stringify(searchModelString);
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/CommonCode/GetAllPlanActions?searchModelString=${searchModel}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  GetFileData(fileCode: string, dataFileToProcessDetailsID: number): Observable<any> {
    // let searchModelString = JSON.stringify(searchModel);
    return this.httpClient.get<any>(`${environment.serviceApiUrl}/api/FileTemplateType/GetFileData?fileCode=${fileCode}&dataFileToProcessDetailsID=${dataFileToProcessDetailsID}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as any;
      })
    );
  }

  /**
  * Purpose : To get CMS File type dropdown list
  * @author Tisa jodhani #O9-340 on 31 August, 2022 : Filetype Dropdown List
  */
  GetCMSFileList(): Observable<FileSubCategoryModel[]> {
    return this.httpClient.get<FileSubCategoryModel[]>(`${environment.serviceApiUrl}/api/FileTemplateType/GetCMSFileTypes`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as FileSubCategoryModel[];
      })
    );
  }
}
