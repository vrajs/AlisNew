import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
import { map, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';
import { HasPlanConfigurationData } from '@app/core/models/administration/configuration/has-plan-configuration-data.model';
import { CopyPlanModel, Plan, PlanViewModel, TerminateBenefit, OData} from '@app/core/models';
import { ODataBuilderService } from '../../common/odata-builder.service';
import { IForOfState } from '@infragistics/igniteui-angular';

@Injectable()
export class PlanService {

  constructor(private httpClient: HttpClient, private oDatabuilderSrvice: ODataBuilderService) {
  }

  /**
   * Purpose: Method is use to get plan list
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get plan list
   */
  get(): Observable<Plan[]> {
    return this.httpClient.get<Plan[]>(`${environment.serviceApiUrl}/api/Plan`);
  }

  getPlans(virtulizationState?: IForOfState, searchText?: string, containProperty?: string): Observable<OData<Plan>> {
    let url = `${environment.serviceApiUrl}/odata/Plans`;
    let buildQuery = this.oDatabuilderSrvice.buildDataUrlForScroll(url, virtulizationState, searchText, containProperty);
    return this.httpClient.get<OData<Plan>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<Plan>(res);
      })
    );
  }

  /**
   * Purpose: Method is use to get plan list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get plan list by id
   */
  getById(planID: number): Observable<Plan> {
    return this.httpClient.get<Plan>(`${environment.serviceApiUrl}/api/plan/${planID}`);
  }

  /**
   * Purpose: Method is use to get plan list by id
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - get plan list by id
   */
   getReadonly(planID: number): Observable<PlanViewModel> {
    return this.httpClient.get<PlanViewModel>(`${environment.serviceApiUrl}/api/plan/GetReadonly/${planID}`);
  }

  /**
   * Purpose: Method is use to insert plan record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - insert plan record
   */
  createOrUpdate(plan: Plan): Observable<Number> {
    if (plan.healthPlanID === 0) {
      return this.httpClient.post<number>(`${environment.serviceApiUrl}/api/plan`, plan);
    }
    else{
      return this.httpClient.put<number>(`${environment.serviceApiUrl}/api/plan`, plan);
    }
    
  }

  /**
   * Purpose: Method is use to delete plan record
   *
   * @author Kiran Panchal #KW-209 on 21-Sep-2022 - delete plan record
   */
  delete(id: number): Observable<Number> {
      return this.httpClient.delete<Number>(`${environment.serviceApiUrl}/api/plan/${id}`);
  }

  addBenefits(healthPlanId: number, benefits: number[], benefitEffectiveDate: Date) {
    let data = { addPlanBenefitsModel: { HealthPlanId: healthPlanId, BenefitHeaderIds: benefits } };
    return this.httpClient.put(environment.serviceApiUrl + "/api/plan/AddPlanBenefits", JSON.stringify({ HealthPlanId: healthPlanId, BenefitHeaderIds: benefits, EffectiveDate: benefitEffectiveDate }));
  }

  terminate(terminatePlan: TerminateBenefit) {
    return this.httpClient.put(environment.serviceApiUrl + "/api/plan/TerminatePlan", JSON.stringify(terminatePlan));
  }

  copy(copyPlan: CopyPlanModel): Observable<any> {
      return this.httpClient.patch(environment.serviceApiUrl + "/api/plan/CopyHealthPlan/", JSON.stringify(copyPlan));
  }

  // copy(copyPlan: CopyPlan): Observable<number> {
  //     return this.httpClient.patch(environment.serviceApiUrl + "/api/plan/CopyHealthPlan/", JSON.stringify(copyPlan))
  //         .map((response: Response) => <number>response.json());
  // }

  removePlanBenefit(healthPlanId: number, benefitId: number) {
      return this.httpClient.delete(environment.serviceApiUrl + "/api/plan/RemovePlanBenefit/HealthPlanID/" + healthPlanId + "/BenefitHeaderID/" + benefitId);
  }
  removeOrTermPlanBenefits(healthPlanId: number, benefits: number[], termDate: Date, benefitTerminationReason: string, recordStatus: number) {
      return this.httpClient.put(environment.serviceApiUrl + "/api/plan/RemoveOrTermPlanBenefits", JSON.stringify({ HealthPlanId: healthPlanId, BenefitHeaderIds: benefits, TermDate: termDate, RecordStatusChangeReason: benefitTerminationReason, RecordStatus: recordStatus }));
  }
  checkPlanConfigurationHasData(healthPlanId: number): Observable<HasPlanConfigurationData> {
      return this.httpClient.get<HasPlanConfigurationData>(environment.serviceApiUrl + '/api/plan/CheckPlanConfigurationHasData/' + healthPlanId);
  }
}
