import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RuleHeaderCapitationModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderCapitationService {

    apiBaseUrl: string = '/api/RuleHeaderCapitation';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderCapitationData(ruleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderCapitationModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderCapitations`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderCapitationModel>>(`${dynamicUrl}&$orderby=RuleHeaderCapitationId asc&RuleHeaderID=${ruleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderCapitationModel>(res);
            })
        );
    }


    getById(ruleHeaderID: number): Observable<RuleHeaderCapitationModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderCapitationModel;
            })
        );
    }

    create(ruleHeaderCapitation: RuleHeaderCapitationModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderCapitation).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderCapitation: RuleHeaderCapitationModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderCapitation).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    delete(ruleHeaderCapitationID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderCapitationID}`).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }
}
