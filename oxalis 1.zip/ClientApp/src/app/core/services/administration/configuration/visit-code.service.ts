//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { VisitCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class VisitCodeService {

  constructor(private httpClient: HttpClient) { }
  
   /**
  * Purpose: Method is use to get visit code
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get visit code
  */
  get(): Observable<VisitCodeModel[]> {
    return this.httpClient.get<VisitCodeModel[]>(`${environment.serviceApiUrl}/api/VisitCode`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel[]
      })
    );      
  }
  
   /**
  * Purpose: Method is use to get visit code for view
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get visit code for view
  */
  getByIdForView(visitCodeId: number): Observable<VisitCodeModel> {
    return this.httpClient.get<VisitCodeModel>(`${environment.serviceApiUrl}/api/VisitCode/GetByIdForView/${visitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel
      })
    );     
  }

   /**
  * Purpose: Method is use to get visit code by id
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - get visit code by id
  */
  getById(visitCodeId: number): Observable<VisitCodeModel> {
    return this.httpClient.get<VisitCodeModel>(`${environment.serviceApiUrl}/api/VisitCode/${visitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel
      })
    );     
  }

  /**
  * Purpose: Method is use to create visit code
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - create visit code 
  */
  create(model: VisitCodeModel): Observable<VisitCodeModel>  {
    return this.httpClient.post<VisitCodeModel>(`${environment.serviceApiUrl}/api/VisitCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel;
      })
    );      
  }

  /**
  * Purpose: Method is use to update visit code
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - update visit code 
  */
  update(model: VisitCodeModel): Observable<VisitCodeModel>  {
    return this.httpClient.put<VisitCodeModel>(`${environment.serviceApiUrl}/api/VisitCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel;
      })
    );    
  }

  /**
  * Purpose: Method is use to delete visit code
  * @author Gaurav Vaghela #O9-53 on 28-May-2022 - delete visit code 
  */
  delete(visitCodeId: number): Observable<VisitCodeModel>  {
    return this.httpClient.delete<VisitCodeModel>(`${environment.serviceApiUrl}/api/VisitCode/${visitCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as VisitCodeModel;
      })
    );   
  }
}
