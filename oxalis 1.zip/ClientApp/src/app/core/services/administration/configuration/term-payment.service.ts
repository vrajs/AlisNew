//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namsespace
import { Utils } from '@app/common/app-functions';
import { environment } from '@environments/environment';
//#endregion

//#region Services Namsespace
import { ODataBuilderService } from "@app/core/services";
import { TermPaymentModel } from '@app/core/models/administration/configuration/term-payment.model';
import { TermDrgGroupModel } from '@app/core/models/administration/configuration/term-drg-group.model';
import { TermDrgPaymentPayPercentModel } from '@app/core/models/administration/configuration/term-drg-payment-pay-percent.model';
import { TermFeeScheduleModel } from '@app/core/models/administration/configuration/term-fee-schedule.model';

//#endregion

@Injectable()

export class TermPaymentService {  

  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

   /**
  * Purpose: Method is use to get term services group list
  * @author Shivam Modi  28-May-2022 - get term services group list
  */
  // getTermPaymentList(url: string, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<TermPaymentModel>> {
  //   let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/TermPayment`, filteringArgs, sortingArgs, index, perPage) + url;
  //   return this.httpClient.get<OData<TermPaymentModel>>(dynamicUrl).pipe(
  //     map(res => {
  //       res = Utils.camelizeKeys(res);
  //       return new OData<TermPaymentModel>(res);
  //     })
  //   );
  // }

  // getTermPaymentList(id:number){
  //   return this.httpClient.get(`${environment.serviceApiUrl}/api/TermServiceGroup/GetTermServiceGroupByTermHeaderId/${id}`).pipe(
  //         map(res => {
  //           return res;
  //         })
  //       );
  // }

  getActiveTermPaymentByTermHeaderID(id:number): Observable<TermPaymentModel[]>{
    return this.httpClient.get<TermPaymentModel[]>(`${environment.serviceApiUrl}/api/TermPayment/GetActiveTermPaymentByTermHeaderID/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel[];
      })
    );
  }

  getTermPaymentHistoryByTermHeaderID(id:number): Observable<TermPaymentModel[]>{
    return this.httpClient.get<TermPaymentModel[]>(`${environment.serviceApiUrl}/api/TermPayment/GetTermPaymentHistoryByTermHeaderID/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel[];
      })
    );
  }

  getDRGGroup(): Observable<TermDrgGroupModel[]>{
    return this.httpClient.get<TermDrgGroupModel[]>(`${environment.serviceApiUrl}/api/DRGGroup`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermDrgGroupModel[];
      })
    );
  }

  getFeeScheduleList(): Observable<TermFeeScheduleModel[]>{
    return this.httpClient.get<TermFeeScheduleModel[]>(`${environment.serviceApiUrl}/api/FeeScheduleHeader`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermFeeScheduleModel[];
      })
    );
  }


  getDrgPaymentPayPercent(): Observable<TermDrgPaymentPayPercentModel[]>{
    return this.httpClient.get<TermDrgPaymentPayPercentModel[]>(`${environment.serviceApiUrl}/api/DRGPaymentPayPercent`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermDrgPaymentPayPercentModel[];
      })
    );
  }
  
  getTermPaymentByTermHeaderID(id:number,paymentTypeId:number): Observable<TermPaymentModel[]>{
    return this.httpClient.get<TermPaymentModel[]>(`${environment.serviceApiUrl}/api/TermPayment/GetTermPaymentByTermHeaderID/${id}/${paymentTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel[];
      })
    );
  }

   /**
  * Purpose: Method is use to get term services group by id
  * @author Shivam Modi  28-May-2022 - get term services group by id
  */
  getById(id: number): Observable<TermPaymentModel> {
    return this.httpClient.get<TermPaymentModel>(`${environment.serviceApiUrl}/api/TermPayment/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel;
      })
    );
  }

   /**
  * Purpose: Method is use to create term services group
  * @author Shivam Modi  28-May-2022 - create term services group
  */
  create(model: TermPaymentModel): Observable<TermPaymentModel> {
    return this.httpClient.post<TermPaymentModel>(`${environment.serviceApiUrl}/api/TermPayment`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel;
      })
    );
  }

  /**
  * Purpose: Method is use to update term services group
  * @author Shivam Modi  28-May-2022 - update term services group
  */
  update(model: TermPaymentModel): Observable<TermPaymentModel> {
    return this.httpClient.put<TermPaymentModel>(`${environment.serviceApiUrl}/api/TermPayment`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel;
      })
    );
  }

  /**
  * Purpose: Method is use to delete term services group
  * @author Shivam Modi  28-May-2022 - delete term services group
  */
  delete(id: number): Observable<TermPaymentModel> {
    return this.httpClient.delete<TermPaymentModel>(`${environment.serviceApiUrl}/api/TermPayment/${id}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as TermPaymentModel;
      })
    );
  }
}
