//#region System Namespace
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
//#endregion

//#region Global Namespace
import { Utils } from '@app/common/app-global';
import { BillTypeCodeModel, CPTCodeModel, DRGCodeModel, HCCCodeModel, ICDCodeModel, NDCCodeModel, POSCodeModel, RevenueCodeModel, StandardCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
//#endregion

@Injectable()

export class StandardCodeService {

  constructor(private httpClient: HttpClient) { }

 /**
   * Purpose: Method is use to get ICD code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get icd code by id
   */
  getICDCodeById(standardCodeID: number): Observable<ICDCodeModel> {

    return this.httpClient.get<ICDCodeModel>(`${environment.serviceApiUrl}/api/ICDCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as ICDCodeModel
      })
    );
  }

   /**
   * Purpose: Method is use to get CPT code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get CPT code by id
   */
  getCPTCodeById(standardCodeID: number): Observable<CPTCodeModel> {
    return this.httpClient.get<CPTCodeModel>(`${environment.serviceApiUrl}/api/CPT/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as CPTCodeModel
      })
    );
  }

   /**
   * Purpose: Method is use to get revenue code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get revenue code by id
   */
  getRevenueCodeById(standardCodeID: number): Observable<RevenueCodeModel> {
    return this.httpClient.get<RevenueCodeModel>(`${environment.serviceApiUrl}/api/RevenueCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RevenueCodeModel
      })
    );
  }

   /**
   * Purpose: Method is use to get POS code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get POS code by id
   */
  getPOSCodeById(standardCodeID: number): Observable<POSCodeModel> {
    return this.httpClient.get<POSCodeModel>(`${environment.serviceApiUrl}/api/POSCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as POSCodeModel
      })
    );
  }

   /**
   * Purpose: Method is use to get HCC code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get HCC code by id
   */
  getHCCCodeById(standardCodeID: number): Observable<HCCCodeModel> {
    return this.httpClient.get<HCCCodeModel>(`${environment.serviceApiUrl}/api/HCCCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HCCCodeModel
      })
    );
  }

   /**
   * Purpose: Method is use to get NDC code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get NDC code by id
   */
  getNDCCodeById(standardCodeID: number): Observable<NDCCodeModel> {
    return this.httpClient.get<NDCCodeModel>(`${environment.serviceApiUrl}/api/NDCCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as NDCCodeModel
      })
    );   
  }

   /**
   * Purpose: Method is use to get bill type code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get bill type code by id
   */
  getBillTypeCodeById(standardCodeID: number): Observable<BillTypeCodeModel> {
    return this.httpClient.get<BillTypeCodeModel>(`${environment.serviceApiUrl}/api/BillTypeCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as BillTypeCodeModel
      })
    );       
  }

   /**
   * Purpose: Method is use to get DRG code by id
   * @author Gaurav Vaghela # on 28-APR-2022 - get DRG code by id
   */
  getDRGCodeById(standardCodeID: number): Observable<DRGCodeModel> {
    return this.httpClient.get<DRGCodeModel>(`${environment.serviceApiUrl}/api/DRGCode/` + standardCodeID).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as DRGCodeModel
      })
    );        
  }

   /**
   * Purpose: Method is use to save ICD code
   * @author Gaurav Vaghela # on 28-APR-2022 - save ICD code
   */
  saveICDCode(model: ICDCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/ICDCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to save CPT code
   * @author Gaurav Vaghela # on 28-APR-2022 - save CPT code
   */
  saveCPTCode(model: CPTCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/CPT`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

/**
   * Purpose: Method is use to save revenue code
   * @author Gaurav Vaghela # on 28-APR-2022 - save revenue code
   */
  saveRevenueCode(model: RevenueCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/RevenueCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to save POS code
   * @author Gaurav Vaghela # on 28-APR-2022 - save POS code
   */
  savePOSCode(model: POSCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/POSCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to save NDC code
   * @author Gaurav Vaghela # on 28-APR-2022 - save NDC code
   */
  saveNDCCode(model: NDCCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/NDCCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );

  }

  /**
   * Purpose: Method is use to save DRG code
   * @author Gaurav Vaghela # on 28-APR-2022 - save DRG code
   */
  saveDRGCode(model: DRGCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/DRGCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to save HCC code
   * @author Gaurav Vaghela # on 28-APR-2022 - save HCC code
   */
  saveHCCCode(model: HCCCodeModel) {
    return this.httpClient.post(`${environment.serviceApiUrl}/api/HCCCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to update ICD code
   * @author Gaurav Vaghela # on 28-APR-2022 - update ICD code
   */
  updateICDCode(model: ICDCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/ICDCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to update CPT code
   * @author Gaurav Vaghela # on 28-APR-2022 - update CPT code
   */
  updateCPTCode(model: CPTCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/CPT`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

/**
   * Purpose: Method is use to update revenue code
   * @author Gaurav Vaghela # on 28-APR-2022 - update revenue code
   */
  updateRevenueCode(model: RevenueCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/RevenueCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to update POS code
   * @author Gaurav Vaghela # on 28-APR-2022 - update POS code
   */
  updatePOSCode(model: POSCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/POSCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to update NDC code
   * @author Gaurav Vaghela # on 28-APR-2022 - update NDC code
   */
  updateNDCCode(model: NDCCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/NDCCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );

  }

  /**
   * Purpose: Method is use to update DRG code
   * @author Gaurav Vaghela # on 28-APR-2022 - update DRG code
   */
  updateDRGCode(model: DRGCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/DRGCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

  /**
   * Purpose: Method is use to update HCC code
   * @author Gaurav Vaghela # on 28-APR-2022 - update HCC code
   */
  updateHCCCode(model: HCCCodeModel) {
    return this.httpClient.put(`${environment.serviceApiUrl}/api/HCCCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res;
      })
    );
  }

}
