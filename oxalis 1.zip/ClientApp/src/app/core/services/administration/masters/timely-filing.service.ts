import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-global";
import { OData, TimelyFilingModel } from "@app/core/models";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";
import { ODataBuilderService } from "../..";

@Injectable()
export class TimelyFilingService {

    apiBaseUrl: string = '/api/TimelyFiling';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) { }

    getTimelyFillingData(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<TimelyFilingModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/TimelyFilings`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<TimelyFilingModel>>(dynamicUrl).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<TimelyFilingModel>(res);
            })
        );
    }

    get(): Observable<TimelyFilingModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as TimelyFilingModel[];
            })
        )
    }

    getById(TimelyFilingID: number): Observable<TimelyFilingModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${TimelyFilingID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as TimelyFilingModel;
            })
        )
    }

    create(timelyFiling: TimelyFilingModel):Observable<TimelyFilingModel> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, timelyFiling).pipe(
            map(res =>{
                res = Utils.camelizeKeys(res);
                return res as TimelyFilingModel;
            })
        );
    }

    update(timelyFiling: TimelyFilingModel) {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, timelyFiling);
    }

    delete(timelyFilingID: number) {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${timelyFilingID}`);
    }
}
