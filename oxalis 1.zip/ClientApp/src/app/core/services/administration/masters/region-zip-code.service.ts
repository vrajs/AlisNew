import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { RegionZipCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

@Injectable()

export class RegionZipCodeService {

  constructor(private httpClient: HttpClient) { }

  get(): Observable<RegionZipCodeModel[]> {
    return this.httpClient.get<RegionZipCodeModel[]>(`${environment.serviceApiUrl}/api/RegionZipCode`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RegionZipCodeModel[];
      })
    );
  }

  getById(regionZipCodeId: number): Observable<RegionZipCodeModel> {
    return this.httpClient.get<RegionZipCodeModel>(`${environment.serviceApiUrl}/api/RegionZipCode/${regionZipCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RegionZipCodeModel;
      })
    );
  }

  create(model: RegionZipCodeModel) {
    return this.httpClient.post<RegionZipCodeModel>(`${environment.serviceApiUrl}/api/RegionZipCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RegionZipCodeModel;
      })
    );
  }

  update(model: RegionZipCodeModel) : Observable<RegionZipCodeModel> {
    return this.httpClient.put<RegionZipCodeModel>(`${environment.serviceApiUrl}/api/RegionZipCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RegionZipCodeModel;
      })
    );
  }

  delete(regionZipCodeId: number) {
    return this.httpClient.delete<RegionZipCodeModel>(`${environment.serviceApiUrl}/api/RegionZipCode/${regionZipCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as RegionZipCodeModel;
      })
    );
  }

}
