import { NgModule, Optional, SkipSelf } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AuthModule } from 'app/core/auth/auth.module';
import { IconsModule } from 'app/core/icons/icons.module';
import { TranslocoCoreModule } from 'app/core/transloco/transloco.module';
import { AccountService, AppPermissionService, BenefitHeaderHealthPlanService, BenefitProviderService, BenefitServiceGroupService, BenefitVisitService, CommonCodeService, CoreConfigService, DeductibleService, DynamicFormService, HomeGrownCodeService, IPALobService, IPAService, MenuService, NotificationService, OrganizationRuleService, MemberService, ODataBuilderService, PlanBenefitPackageService, RegionZipCodeService, RoleService, ServiceGroupService, StandardCodeService, UserService, VisitCodeService, ZipCodeService, AgeGroupService, ProviderService, CustomerSettingService, CopayCoinsuranceService, PreEnrollmentService, ProviderSpecialtyService, ProviderEligibilityService, ProviderContractService, TimelyFilingService, UCRFeeScheduleService, InterestQuickPayService, ModifierDiscountGroupService, ProviderTINService, ProviderEFTService, ProviderIPAService, GroupProviderContractService, ProviderLocationService, LocationService, EDITradingPartnerService, MemberTRRService, RBRVSCodeService, RBRVSService, ClinicalCodeService, POSCodeService, CPTCodeService, AnesConversionFactorService, MemberSpanService, FacilityService, AlertModuleService } from '@app/core/services';
import { BenefitHeaderService } from './services/administration/configuration/benefit-header.service';
import { BenefitCopayCoinsuranceService } from './services/administration/configuration/benefit-copay-coinsurance.service';
import { BenefitCopayDiemService } from './services/administration/configuration/benefit-copay-diem.service';
import { BenefitCodeService } from './services/common/benefit-code.service';
import { LobService } from './services/administration/configuration/lob.service';
import { ContractHeaderService } from './services/administration/configuration/contract-header.service';
import { TermHeaderService } from './services/administration/configuration/term-header.service';
import { TermServiceGroupService } from './services/administration/configuration/term-service-group.service';
import { TermCodeService } from './services/common/term-code.service';
import { TermPaymentService } from './services/administration/configuration/term-payment.service';
import { TermLimitService } from './services/administration/configuration/term-limit.service';
import { MemberEnrollmentService } from './services/operation/member/enrollment.service';
import { ProviderCodeService } from './services/operation/provider/provider-code.service';
import { ProviderNoteService } from './services/operation/provider/provider-note.service';
import { ProviderRelationService } from './services/operation/provider/provider-relation.service';
import { MemberTransactionDetailService } from './services/operation/member/transaction.service';
import { MemberBEQService } from './services/operation/member/member-beq.service';
import { RegionService } from './services/administration/supporting-tables/region.service';
import { ClaimHeaderService, ClaimSearchNevigationService, ClaimAdjudicationService, ClaimDiagnosisService, ClaimEOBEOPService, ClaimEditsService, ClaimNotesService, ClaimOtherInsurance, ClaimOtherPhysicianService, ClaimReferenceService, ClaimService, ClaimUBCodesService } from '@app/core/services/operation/claim';
import { SearchCriteriaService } from "@app/core/services/administration/masters/search-criteria.service";
import { AuthService } from '@app/core/services/administration/security/auth.service';
import { OutBoundMappingService } from './services/common/out-bound-mapping.service';
import { TRRFalloutsService } from './services/operation/member/trr-fallouts.service';
import { RefundLetterService, RefundNoteService, RefundPostingService, RefundReceivedService, RefundRequestClaimService, RefundRequestService, RefundStatusService } from './services/operation/refund';
import { BillParameterService, RateCodeService } from './services/finance';
import { CompanyAccountService } from './services/finance/company-account.service';
import { AccountDetailService } from './services/finance/account-detail.service';
import { OrganizationService } from './services/administration/configuration/organization.service';
import { PlanService } from './services/administration/configuration/plan.service';
import { InvoiceService } from './services/operation/member/invoice.service';
import { ProviderCredentialingService } from './services/operation/provider/provider-credentialing.service';
import { ProviderStatusService } from './services/operation/provider/provider-status.service';
import { FileClaimService } from './services/operation/claim/fileClaim.service';
import { CorrespondanceService } from './services/operation/member/correspondance.service';
import { ClaimListingService } from './services/operation/claim/claim-listing.service';
import { ProviderEligibilityLogsService } from './services/operation/provider/provider-eligibility-logs.service';
import { ProviderSharedService } from '@app/shared/Services/providerShared.Service';
import { ClaimEditCodeService } from './services/operation/claim/claim-edit-codes.service';
import { ClaimStatusService } from './services/operation/claim/claim-status.service';
import { ClaimHistoryService } from './services/operation/claim/claim-history.service';
import { MemberCorrespondanceService } from './services/memberCorrespondance/memberCorrespondance.service';



@NgModule({
    imports: [
        AuthModule,
        IconsModule,
        TranslocoCoreModule
    ],
    providers: [
        ODataBuilderService,
        AccountService,
        AppPermissionService,
        CoreConfigService,
        MenuService,
        NotificationService,
        UserService,
        RoleService,
        DynamicFormService,
        CommonCodeService,
        StandardCodeService,
        HomeGrownCodeService,
        ZipCodeService,
        AgeGroupService,
        RegionZipCodeService,
        LobService,
        OrganizationRuleService,
        MemberService,
        InvoiceService,
        ProviderService,
        FileClaimService,
        IPAService,
        IPALobService,
        PlanBenefitPackageService,
        DeductibleService,
        BenefitHeaderService,
        CopayCoinsuranceService,
        BenefitCopayCoinsuranceService,
        BenefitCopayDiemService,
        BenefitCodeService,
        TermCodeService,
        ServiceGroupService,
        BenefitServiceGroupService,
        BenefitProviderService,
        ProviderSharedService,
        VisitCodeService,
        BenefitVisitService,
        BenefitHeaderHealthPlanService,
        PreEnrollmentService,
        TRRFalloutsService,
        ContractHeaderService,
        TermHeaderService,
        TermServiceGroupService,
        TermPaymentService,
        TermLimitService,
        CustomerSettingService,
        ProviderSpecialtyService,
        ProviderStatusService,
        ProviderCredentialingService,
        MemberEnrollmentService,
        CorrespondanceService,
        MemberCorrespondanceService,
        ProviderCodeService,
        ProviderNoteService,
        ProviderEligibilityService,
        ProviderEligibilityLogsService,
        ProviderContractService,
        TimelyFilingService,
        UCRFeeScheduleService,
        InterestQuickPayService,
        ModifierDiscountGroupService,
        ProviderRelationService,
        MemberTransactionDetailService,
        ProviderTINService,
        ProviderEFTService,
        ProviderIPAService,
        GroupProviderContractService,
        ProviderLocationService,
        LocationService,
        EDITradingPartnerService,
        MemberBEQService,
        MemberTRRService,
        RegionService,
        RBRVSCodeService,
        RBRVSService,
        ClaimHeaderService,
        ClaimSearchNevigationService,
        SearchCriteriaService,
        AuthService,
        ClaimAdjudicationService,
        ClaimDiagnosisService,
        ClaimEOBEOPService,
        ClaimEditsService,
        ClaimNotesService,
        ClaimOtherInsurance,
        ClaimOtherPhysicianService,
        ClaimReferenceService,
        ClaimService,
        ClaimStatusService,
        ClaimUBCodesService,
        ClinicalCodeService,
        DatePipe,
        POSCodeService,
        CPTCodeService,
        AnesConversionFactorService,
        OutBoundMappingService,
        MemberSpanService,
        RefundLetterService,
        RefundNoteService,
        RefundPostingService,
        RefundReceivedService,
        RefundRequestService,
        RefundRequestClaimService,
        RefundStatusService,
        RateCodeService,
        BillParameterService,
        CompanyAccountService,
        AccountDetailService,
        OrganizationService,
        PlanService,
        FacilityService,
        ClinicalCodeService,
        AlertModuleService,
        ClaimListingService,
        ClaimEditCodeService,
        ClaimHistoryService
    ]
})
export class CoreModule {
    /**
     * Constructor
     */
    constructor(
        @Optional() @SkipSelf() parentModule?: CoreModule
    ) {
        // Do not allow multiple injections
        if (parentModule) {
            throw new Error('CoreModule has already been loaded. Import this module in the AppModule only.');
        }
    }
}
