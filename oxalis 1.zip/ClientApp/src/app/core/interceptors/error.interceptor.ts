import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';
import { catchError, Observable } from 'rxjs';
import { AlertMessageType, AppConstant, HTTPStatusCode, Utils } from '@app/common/app-global';
import { AuthService, NotificationService } from '@app/core/services';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    private data: any = null;

    constructor(
        private authService: AuthService,
        private notificationService: NotificationService
    ) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(
            catchError((err: HttpErrorResponse) => {
                this.handleError(err);
                throw err;
            }));
    }

    private handleError(error: HttpErrorResponse) {

        this.data = JSON.parse(JSON.stringify(error.error));
        // this.data = Utils.camelizeKeys(this.data);

        if (error.status == HTTPStatusCode.BadRequest) {
            if( typeof(this.data) === 'string' ){
                this.notificationService.showMessage(AlertMessageType.Error,this.data);
            } else {
                Object.keys(this.data).forEach(key => {
                    let value = this.data[key];
                    this.notificationService.showMessage(AlertMessageType.Error, key + " : " + value);
                });
            }
        }
        else if (error.status == HTTPStatusCode.NotAcceptable) {
            // this.data = error.error.json();
            Object.keys(this.data).forEach(key => {
                let value = this.data[key];
                if (value.errors.length > 0) {
                    this.notificationService.showMessage(AlertMessageType.Info, "Validation : " + key, value.errors[0].errorMessage);
                }
            });
        }
        else if (error.status == HTTPStatusCode.NotFound) {
            // this.data = error.error.text();
            this.notificationService.showMessage(AlertMessageType.Error, this.data);
        }
        else if (error.status == HTTPStatusCode.UnAuthorized) {
            this.notificationService.showMessage(AlertMessageType.Error, AppConstant.unauthorizeRedirection);
            this.authService.removeLocalStore();
            this.authService.redirectLogoutUser();
        }
        else if (error.status == 500) {
            if (!Utils.isJson(error.error)) {
                this.notificationService.showMessage(AlertMessageType.Error, error.error);
            }
            else {
                this.data = error.error.json();
                Object.keys(this.data).forEach(key => {
                    let value = this.data[key];
                    this.notificationService.showMessage(AlertMessageType.Error, value);
                });
            }
        }
        else if (error.status > 500 && error.status <= 511) {
            this.notificationService.showMessage(AlertMessageType.Error, this.data);
        }
        else {
            //for demo purpose
            // this.notificationService.showMessage(AlertMessageType.Error, error.message);
        }

        throw error;

    }

}
